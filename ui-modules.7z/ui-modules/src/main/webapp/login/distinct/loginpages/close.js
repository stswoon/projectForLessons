(function () {
    var body = window.top.document.body,
        $body = window.top.angular.element(body),
        loginFactory = $body.injector().get("loginFactory"),
        afterLoginFactory = $body.injector().get("afterLoginFactory"),
        $rootScope = $body.injector().get("$rootScope");

    var data = (function (hash) {
        hash = hash.replace('#', '');
        var elements = hash.split('&');
        var result = {};
        result.data = [];
        for (var i = 0; i < elements.length; i++) {
            var param = elements[i].split('=');
            result.data[param[0]] = param[1];
        }
        return result;


    })(decodeURIComponent(window.location.hash));

    setTimeout(function () {
        if (afterLoginFactory.loginInClose) afterLoginFactory.loginInClose(loginFactory);
        loginFactory.login(data);
        $rootScope.$apply();
    }, 0);
})();
