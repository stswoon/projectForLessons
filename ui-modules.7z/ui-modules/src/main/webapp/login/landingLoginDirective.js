function landingLoginDirective($window,  $q, loginFactory, restServiceFactory) {
    return {
        scope: {},
        bindToController: {},
        templateUrl: "ui-modules/login/source/landing-login.tmpl.html", //todo alias
        controller: function ($scope, $rootScope, $timeout, $window, localizationFactory) {
            var self = this;
            self.iframeLoading = false;
            self.loginFactory = loginFactory;
            self.l10n = localizationFactory;

            self._oldTenant = null;
            var waitFrame = function () {
                if (loginFactory.getTenantDNS() && self._oldTenant != loginFactory.getTenantDNS()) {
                    self.iframeLoading = true;
                    //Hard set visible to true if iframe doesn't call onload
                    $timeout(function () {
                        self.iframeLoading = false;
                    }, 5000);

                    self._oldTenant = loginFactory.getTenantDNS();

                    var iframe = document.getElementById("frame");
                    iframe.style.visibility = "hidden";
                    iframe.onload = function () {
                        iframe.style.visibility = "";
                        $rootScope.$apply();
                    };
                }
            };
            waitFrame();
            loginFactory.onLoginUrlChange(waitFrame);

            self.getServiceAvailability = function () {
                return self.isServiceAvailable;
            };

            self.isLoading = function () {
                return self.iframeLoading || self.loginFactory.loading;
            };

            self.onTenantDNSFormSubmit = function () {
                var defer = $q.defer();
                if (!defer) {
                    loginFactory.getTenantId(loginFactory.tenantDNS);
                    return;
                }

                loginFactory.getTenantId(loginFactory.tenantDNS, defer);

                defer.promise.then(function() {
                    self.isCorrectDomain = true;
                    $timeout(function () {
                        var element = $window.document.getElementById("tenantDNS");
                        if (element) {
                            element.blur();
                        }
                    });
                }, function() {
                    self.isCorrectDomain = false;
                });
            };

            function getBrowserLanguage() {
                if (navigator.languages != undefined) {
                    return navigator.languages[0];
                } else {
                    return navigator.language;
                }
            }

            var script = document.createElement("script");
            script.src = restServiceFactory.identity.ip + "/auth/realms/" + (loginFactory.tenantId || "Cloud") + "/";
            script.async = true;
            script.id = "checkAuthScript";
            script.onload = function () {
                self.isServiceAvailable = true;
                console.log('auth service is available', script.src);
                document.head.removeChild(script);
                $scope.$digest();
            };
            script.onerror = function (error) {
                self.isServiceAvailable = false;
                console.log('auth service is not available', error, script.src);
                document.head.removeChild(script);
                $scope.$digest();
            };
            document.head.appendChild(script);

            function removeProtocol(url) {
                return url.substring(url.indexOf("://") + 1);
            }

            var loginFrame = document.getElementById('frame');
            window.addEventListener("message", function(event) {
                var origin = removeProtocol(event.origin);

                if (restServiceFactory.identity.address.indexOf(origin) != -1) {
                    var data = event.data;

                    try {
                        data = JSON.parse(data);
                    } catch (ex) {
                        return;
                    }

                    console.log('post message event', event);
                    if (data.eventType === "frameLoaded") {
                        $timeout(function () {
                            self.iframeLoading = false;
                        });
                    }
                    if (data.height) {
                        var frameHeight = data.height;
                        loginFrame.height = frameHeight + 50;
                    }
                }
            });
        },

        controllerAs: "landingLoginCtrl",

        link: function (scope, el, attrs, ctrl) {
        }
    };
}