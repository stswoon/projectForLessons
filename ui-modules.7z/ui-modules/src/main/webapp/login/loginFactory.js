function loginFactory($window, $rootScope, $sce, $http, $q,
                      cookiesFactory, SessionService, restServiceFactory,
                      routeFactory, afterLoginFactory,
                      injectLoginFunctionalityFactory, localizationFactory) {

    function assign(receiver, supplier) {
        for (var prop in supplier) {
            if (supplier.hasOwnProperty(prop)) {
                receiver[prop] = supplier[prop];
            }
        }
        return receiver;
    }

    //https://gist.github.com/darrenscerri/5c3b3dcbe4d370435cfa
    var Middleware = function() {};
    Middleware.prototype.use = function(fn) {
        var self = this;

        this.go = (function(stack) {
            return function(next) {
                stack.call(self, function() {
                    fn.call(self, next.bind(self));
                });
            }.bind(this);
        })(this.go);
    };
    Middleware.prototype.go = function(next) {
        next();
    };




    var tenantToUserLoginMiddleware = new Middleware();

    var globals = null;
    var cookieParams = null;

    var factory = {};
    var nonce;
    var tenantDNSChangeHandlers = [];

    factory.login = function (data) {
        factory.parsedToken = parseToken(data.data["access_token"]);
        var parsedToken = factory.parsedToken;
        if (!this.validateToken(parsedToken)) {
            console.log("Invalid nonce");
        }

        SessionService.removeAnonymusState();
        SessionService.setAccessToken(data.data["access_token"]);
        SessionService.setTokenType("Bearer");
        //SessionService.setTokenType(data.data["token_type"]);

        factory.setCredentials(parsedToken["preferred_username"], parsedToken["tenant-id"]);
        factory.clearLoginUrl();

        if (afterLoginFactory.login) afterLoginFactory.login(factory);

        $rootScope.$emit('loginFactory:login', {
            tenantId: factory.getURLTenantId(),
            tenantDNS: factory.getTenantDNS(),
            userName: factory.getUserName()
        });
    };

    factory.clearURLTenantId = function () {
        if (window.location.href.indexOf("?tenantDNS=") > 0) {
            window.location.href = window.location.href.split("?tenantDNS=")[0];
        }
        factory.tenantId = null;
        factory.tenantDNS = null;
        cookiesFactory.remove('globals', cookieParams);
        cookiesFactory.putObject('globals', {}, cookieParams);
        globals = {};
        handleTenantDnsChange();
    };

    factory.setURLTenantId = function (id) {
        factory.tenantId = id;
        cookiesFactory.putInObject('globals', 'tenantId', id, cookieParams);
        if (!factory.loading) {
            setLoginUrl(); //depends on tenantId
        }
    };
    factory.getURLTenantId = function () {
        if (factory.tenantId) {
            return factory.tenantId;
        } else if (globals) {
            return globals.tenantId;
        }
    };
    // if (factory.getURLTenantId()) {
    //     factory.setLoginUrl();
    // }
    // factory.getLoginUrl = function() {
    //     return factory.loginUrl;
    // };

    /**
     * @protected
     */
    factory.setTenantDNS = function (tenantDNS) {
        factory.tenantDNS = tenantDNS;
        cookiesFactory.putInObject('globals', 'tenantDNS', tenantDNS, cookieParams);
    };
    factory.getTenantDNS = function () {
        if (factory.tenantDNS) {
            return factory.tenantDNS;
        } else if (globals) {
            return globals.tenantDNS;
        }
    };

    var customHtml = "";
    factory.setCustomHtml = function(html) {
        customHtml = html ? $sce.trustAsHtml(html) : "";

    };
    factory.getCustomHtml = function() {
        return customHtml;
    };

    factory.setCredentials = function (userName, tenantId) {
        factory.userName = userName;

        console.log('**************************');

        cookiesFactory.putObject('globals', {
            userName: userName,
            tenantId: tenantId || factory.tenantId,
            tenantDNS: factory.tenantDNS
        }, cookieParams);
    };

    factory.clearCredentials = function () {
        //have to save tenantId
        var tenantIdSaved = factory.tenantId,
            tenantDNSSaved = factory.tenantDNS;

        SessionService.clearSessionServiceInfo();
        cookiesFactory.remove('globals', cookieParams);
        cookiesFactory.putObject('globals', {}, cookieParams);
        globals = {};
        factory.clearUserInfo();

        factory.setURLTenantId(tenantIdSaved);
        factory.setTenantDNS(tenantDNSSaved);

        handleTenantDnsChange();
    };

    factory.getUserName = function () {
        return factory.userName;
    };

    factory.clearUserInfo = function () {
        factory.tenantId = null;
        factory.tenantDNS = null;
        factory.userName = null;
    };

    factory.logout = function () {
        factory.loading = true;
        var script = document.createElement('script');
        script.src = restServiceFactory.identity.address_logout.replace("{tenantId}", factory.tenantId);
        script.onload = function () {
            $rootScope.$broadcast('clearData');
            if (afterLoginFactory.logout) afterLoginFactory.logout(factory);
            document.head.removeChild(script);
            console.log('loginFactory get logout success', script.src);
            logoutComplete();
        };
        script.onerror = function () {
            document.head.removeChild(script);
            console.log('loginFactory get logout error', script.src);
            logoutComplete();
        };
        document.head.appendChild(script);

        if (!factory.hideLoggedDomain) {
            factory.clearURLTenantId();
        }
        factory.clearCredentials();

        $rootScope.$emit('loginFactory:logout');

        function logoutComplete() {
            factory.loading = false;
            if (factory.hideLoggedDomain && factory.tenantId) {
                factory.setURLTenantId(factory.tenantId);
            }
            $rootScope.$digest();
        }
    };

    factory.clearLoginUrl = function () {
        factory.loginUrl = null;
        handleLoginUrlChange();
    };

	var loginClearCallbacks = [];
    function handleLoginUrlChange() {
        loginClearCallbacks.forEach(function(callback) {
            callback();
        });
    }
    factory.onLoginUrlChange = function (callback) {
        loginClearCallbacks.push(callback);
    };

    factory.getTenantId = function (tenantDNS, defer, callback) {
        factory.setTenantDNS(tenantDNS);

        var _path,
            reservedDNSArr = ["master", "Cloud", "ATT", "cloud-common"];

        if (~reservedDNSArr.indexOf(tenantDNS)) {
            tenantToUserLoginMiddleware.go(function () {
                factory.setURLTenantId(tenantDNS);
                factory.setTenantDNS(tenantDNS);
                SessionService.setTenant(tenantDNS);
                if (callback) callback();
                if (defer) defer.resolve();
            });
			handleTenantDnsChange();
        } else {
            _path = restServiceFactory.getTenantId.replace('{tenantDNS}', tenantDNS);

            $http({
                method: 'GET',
                url: _path,
                headers: {
                    'content-type': 'text/plain'
                },
                transformResponse: undefined
            })
                .then(function (data) {
                    console.log(data);
                    tenantToUserLoginMiddleware.go(function () {
                        factory.setURLTenantId(data.data);
                        factory.setTenantDNS(tenantDNS);
                        SessionService.setTenant(data.data);
                        console.log("loginFactory getTenantId success", _path, data);
                        if (callback) callback();
                        if (defer) defer.resolve();
                    });
					handleTenantDnsChange();
                }, function (error) {
                    console.log("loginFactory getTenantId error", _path, error);
                    if (defer) defer.reject();
                });
        }
    };

    factory.validateToken = function (parsedToken) {
        return (parsedToken && parsedToken["nonce"] == nonce);
    };

    factory.setLoginUrl = setLoginUrl;

    /**
     * Handler will be calle right after tenant was changes. Also it calls after clear tenant data (e.g. logout), so
     * in that case tenantData will contain undefinde values. If handler adds and tenant is already registered than
     * handler will be called immediately.
     *
     * @param handler function(tenantData:{tenantId:string, tenantDNS:string}) to be called after change tenant
     * @return {{remove}} object with method remove to remove handler
     */
    factory.onTenantDNSChange = function (handler) {
        tenantDNSChangeHandlers.push(handler);

        if (factory.getTenantDNS()) {
            handler({
                tenantDNS : factory.getTenantDNS(),
                tenantId : factory.getURLTenantId()
            });
        }

        function createRemover(handler) {
            return {
                remove: function () {
                    for (var i = tenantDNSChangeHandlers.length; --i >= 0;) {
                        if (tenantDNSChangeHandlers[i] == handler) {
                            tenantDNSChangeHandlers.splice(i, 1);
                            break;
                        }
                    }
                }
            }
        }
        return createRemover(handler);
    };

    factory.addTenantToUserLoginMiddleware = function (callback) {
        tenantToUserLoginMiddleware.use(function (next) {
            callback(next);
        })
    };

    assign(factory, injectLoginFunctionalityFactory);

    /*Helpers*/
    function getPath(resource) {
        var path;

        //for local usage
        // if (~window.location.host.indexOf('localhost')) {
        //     path = window.location.protocol + "//" + window.location.host + "/scripts/distinct/" + resource;
        // } else {
        //     path = window.location.protocol + "//" + window.location.host + "/SLS_Cloud/GitRepo/customer-self-service-frontend/src/main/resources/static/scripts/distinct/" + resource;
        // }

        //for cloud usage
        path = window.location.protocol + "//" + window.location.host + "/loginpages/" + resource;

        //if (!window.shoppingContextPath) {
        //
        //    path = window.location.href.replace(window.location.hash, '') + "/cloud-war/jsp/scriptsLiferay/dev/" + resource;
        //}
        //else {
        //    path = window.location.protocol + "//" + window.location.host + "/" + window.shoppingContextPath + "jsp/scriptsLiferay/dev/" + resource;
        //}

        return path;
    }

    function parseToken(token) {
        var base64Url = token.split('.')[1],
            base64 = base64Url.replace('-', '+').replace('_', '/');

        return JSON.parse(window.atob(base64));
    }

    function getLoginUrl(redirectUrl) {
        return restServiceFactory.identity.address.replace("{tenantId}", factory.tenantId)
            + "?response_type=" + restServiceFactory.identity.response_type
            + "&client_id=" + restServiceFactory.identity.client_id
            + "&redirect_uri=" + $window.encodeURIComponent(redirectUrl)
            + "&nonce=" + nonce
            + "&kc_locale=" + localizationFactory.currentLanguage.key;
    }

    function setLoginUrl() {

        var url = getLoginUrl(getPath("close.html"));

        console.log('loginFactory keycloak url', url);

        //this will be read by iframe in landing-distinct.tmpl
        factory.loginUrl = $sce.trustAsResourceUrl(url);

        handleLoginUrlChange();
    }

    //http://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
    function getParameterByName(name, url) {
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)");
        var results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    function getTenantDNSFromParams() {
        if (window.location.href.indexOf("tenantDNS=") > 0) {
            var tenantDNS = getParameterByName("tenantDNS", window.location.href);
            factory.getTenantId(tenantDNS);
            return true;
        } else {
            return false;
        }
    }

    function setGlobals() {
        //https://docs.angularjs.org/api/ngCookies/provider/$cookiesProvider#defaults
        //document.cookie = cookieName +"=" + cookieValue + ";expires=" + myDate
        //      + ";domain=.example.com;path=/";
        //.sdntest.netcracker.com
        //http://stackoverflow.com/questions/5671451/creating-a-javascript-cookie-on-a-domain-and-reading-it-across-sub-domains
        if (restServiceFactory.domain) {
            cookieParams = {
                path: "/",
                domain: restServiceFactory.domain //".netcracker.com"
            };
        }

        if (!globals) {
            globals = cookiesFactory.getObject('globals', cookieParams);
        }
        if (!globals) {
            cookiesFactory.putObject('globals', {}, cookieParams);
            globals = cookiesFactory.getObject('globals', cookieParams);
        }
    }

    function handleTenantDnsChange() {
        var data = {
            tenantId: factory.getURLTenantId(),
            tenantDNS: factory.getTenantDNS()
        };
		for (var i = 0; i < tenantDNSChangeHandlers.length; ++i) {
            tenantDNSChangeHandlers[i](data);
        }
    }

    function generateNonce() {
        return (Math.random() * Date.now()).toString();
    }

    function initData() {
        setGlobals();
        globals = cookiesFactory.getObject('globals', cookieParams);
        nonce = generateNonce();

        console.log(globals);

        var tenantConfigured = false;
        if (routeFactory.data) {
            function onValidTenantId() {
                var idpHint = routeFactory.data.idpHint;
                if (window.authenticated) {
                    setLoginUrl();
                } else if (idpHint) {
                    var url = getLoginUrl($window.location.href)
                        + (idpHint ? ("&kc_idp_hint=" + $window.encodeURIComponent(idpHint)) : "");
                    $window.location.assign(url);
                } else {
                    factory.loading = false;
                    setLoginUrl();
                }
            }

            if (routeFactory.data.tenantId) {
                tenantConfigured = true;
                factory.hideLoggedDomain = true;
                factory.loading = true;
                factory.setURLTenantId(routeFactory.data.tenantId);
                onValidTenantId();
            } else if (routeFactory.data.tenantDNS) {
                tenantConfigured = true;
                factory.hideLoggedDomain = true;
                factory.loading = true;
                var defer = $q.defer();
                factory.getTenantId(routeFactory.data.tenantDNS, defer);
                defer.promise.then(function () {
                    onValidTenantId();
                }, function () {
                    factory.hideLoggedDomain = false;
                    factory.loading = false;
                });
            }
        }

        if (!tenantConfigured && getTenantDNSFromParams() === false) {
            factory.tenantDNS = globals.tenantDNS;
            factory.tenantId = globals.tenantId;

            if (factory.tenantId) {
                //will work if somebody already registerd middleware before login module start
                tenantToUserLoginMiddleware.go(function() {
                    factory.setLoginUrl();
                });
            }

            handleTenantDnsChange();
        }
    }

    initData();

    return factory;
}

(function () {
    function parseHash(hash) {
        hash = hash.replace('#/', '').replace('#', '');
        var result = {};

        var elements = hash.split('&');
        for (var i = 0; i < elements.length; i++) {
            var param = elements[i].split('=');
            result[param[0]] = param[1];
        }
        return result;
    }

    if (location.hash) {
        var args = parseHash(location.hash);
        if (args.access_token) {
            window.authenticated = true;
            window.history.replaceState({}, null, location.pathname);
        }
    }
})();