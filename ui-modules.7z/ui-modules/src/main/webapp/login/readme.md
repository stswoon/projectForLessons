## Login Module
:exclamation: Here described only new functionality, sorry but use source to read about old one

#### TenantDNS - tenantToUserLoginMiddleware
You have ability to register middleware between tenantDNS input and user login with ability
to do async staff.
```javascript
loginFactory.addTenantToUserLoginMiddleware(function (next) {
    setTimeout(function () {
        console.log("Async middleware, TenantDNS = " + loginFactory.getTenantDNS());
        next(); //get flow to next middleware or loginFactory at the end
    }, 5000);
});
```
In case of saved tenant in dns you should register middleware before login module start, e.g.
in so called `initState` which exist in any NC frontend. Another way to use `onTenantDNSChange` handlers.

#### TenantDNS - handler
Sometimes it is needed to get tenant name. But tenant dns may be set by a user after some time.
Or may be provided instantly. Or may be changed any time. To get tenant name use `loginFactory#onTenantDNSChange`:
```javascript
/**
 * data is object like
 * {
 *   tenantId: string, //maybe empty
 *   tenantDNS: string //tenant name, maybe empty
 * }
 */
loginFactory.onTenantDNSChange(function (data) {
    console.log("TenantDNS=" + data.tenantDNS);
});
```
If you need to remove handler use
```javascript
var handlerRegistration = loginFactory.onTenantDNSChange(...);
handlerRegistration.remove();
```

TenantDNS may change after:

1. click change domain button
2. logout clears DNS
3. first page opening may get tenant from cookies

#### Events
Login Module provide some events via angularJs event bus.

Please pay attention that if your service will be loaded after login module it
may skip events but you can use login module api direct, e.g.
```javascript
function yourFactory(loginFactory) {
    console.log(loginFactory.getTenantDNS());
}
```

Events API:
<table>
    <thead>
        <tr>
            <th>Event Name</th>
            <th>Data</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>loginFactory:login</td>
            <td>
<code><pre>
{
    tenantId: string,
    tenantDNS: string, //tenant name
    userName: string
}
</pre></code>
            </td>
            <td>Event after authorization (after click login button and finish of all login callbacks)</td>
        </tr>
        <tr>
            <td>loginFactory:logout</td>
            <td>null</td>
            <td>Event after logout (usually it happens after click logout button)</td>
        </tr>
    </tbody>
</table>

Event subscription example:
```javascript
$rootScope.$on('loginFactory:login', function(event, data) {
    console.log("Tenant name = " + data.tenantDNS);
});
```

