//https://bass.netcracker.com/pages/viewpage.action?spaceKey=UX&title=%5BDRAFT%5D+Umbrella+Module+Loading

'use strict';

//need polyfill (https://github.com/then/promise) and requirejs as deps
var publicApi = publicApi || {};
publicApi.ModuleManager = (function () {
    var DEBUG = false;

    /**
     * Element attribute name in which id of module instance stores
     */
    var MODULE_IN_ELEMENT_ID = "moduleManager-module-id";

    /**
     * Create ModuleManager.
     * You can specify any params in config and the will be available in modules.
     * But some paras are needed only for ModuleManager, e.g. config.requireProxy
     * object which contain require and define method which should works as
     * require\define from ReuireJs lib.
     * @param config - {*}
     * @constructor
     */
    function ModuleManager(config) {
        config = config || {};

        /**
         *  moduleDescriptors[name] = {
         *      name: name,
         *      moduleFactory: moduleFactory,
         *      styleHandlers: [],
         *      moduleInstanceCount: 0,
         *      moduleInstanceNewId: 0,
         *      moduleInstances[MODULE_IN_ELEMENT_ID attr] = {
         *          module: null,
         *          context: null
         *      }
         *  }
         *  moduleFactory: function(context) {
         *      return {
         *          styleSheet: string,
         *          init: function,
         *          destroy: function
         *      }
         *  }
         */
        this._moduleDescriptors = {};
        this._eventBus = new packageApi.EventBus();
        this._config = assign({}, config);

        //try to get requireJs for require\define
        this._requireProxy = config.requireProxy || R || null;
        delete this._config.requireProxy; //remove
        if (!this._requireProxy && require && define) {
            this._requireProxy = {require: require, define: define};
        }
        if (!this._requireProxy) {
            throw new Error("Can't found appropriate realization of requireJs. Please set it in config manually.");
        }
    }

    function assign(receiver, supplier) {
        for (var prop in supplier) {
            if (supplier.hasOwnProperty(prop)) {
                receiver[prop] = supplier[prop];
            }
        }
        return receiver;
    }

    function createContext(element, eventBus, config) {
        var context = {
            getElement: function () {
                return element;
            },
            getEventBus: function () {
                return eventBus;
            },
            getConfig: function () {
                return config;
            }
        };
        return context;
    }

    function loadCss(url, callback) {
        var link = document.createElement("link");
        link.type = "text/css";
        link.rel = "stylesheet";
        link.href = url;
        if (callback) {
            link.onload = function () {
                callback(link);
            }
        }
        document.getElementsByTagName("head")[0].appendChild(link);
    }

    /**
     * Link style sheet and call callback after onload
     */
    //maybe use requirecss https://github.com/guybedford/require-css
    function linkStyleSheet(moduleDescriptor, jsFilePath, callback) {
        if (!moduleDescriptor.style.path) {
            callback();
            return;
        }
        if (moduleDescriptor.style.status === 'ready') {
            callback();
            return;
        }
        if (moduleDescriptor.style.status === 'loading') {
            moduleDescriptor.style.handlers.push(callback);
            return;
        }

        moduleDescriptor.style.status = 'loading';
        moduleDescriptor.style.handlers.push(callback);

        var styleSheetSecondPartUrl = moduleDescriptor.style.path;
        var cssUrl = jsFilePath;
        var index = cssUrl.lastIndexOf("/");
        cssUrl = cssUrl.substr(0, index);
        if (styleSheetSecondPartUrl.indexOf("/") == 0) {
            styleSheetSecondPartUrl = styleSheetSecondPartUrl.substr(1, styleSheetSecondPartUrl.length - 1);
        }
        cssUrl += "/" + styleSheetSecondPartUrl;

        loadCss(cssUrl, function callStyleHandlers(linkElement) {
            moduleDescriptor.style.status = 'ready';
            moduleDescriptor.style.linkElement = linkElement;
            for (var i = 0; i < moduleDescriptor.style.handlers.length; ++i) {
                moduleDescriptor.style.handlers[i]();
            }
            moduleDescriptor.style.handlers = [];
        });
    }

    /**
     * 1. get instance id from element attr
     * 2. call destroy method of module
     * 3. clear html in element
     * 4. remove instance from `_moduleDescriptors`
     * 5. if there is no other instances of this module than remove style link
     */
    function destroyOneModule(moduleDescriptors, moduleName, instanceId) {
        moduleDescriptors[moduleName].moduleInstances[instanceId].instance.destroy();
        moduleDescriptors[moduleName].moduleInstances[instanceId].context.getElement().innerHTML = "";
        moduleDescriptors[moduleName].moduleInstances[instanceId].context.getElement().removeAttribute(MODULE_IN_ELEMENT_ID);
        delete moduleDescriptors[moduleName].moduleInstances[instanceId];
        moduleDescriptors[moduleName].moduleInstanceCount--;
        if (DEBUG) console.log("ModuleManager:moduleInstanceCount=" + moduleDescriptors[moduleName].moduleInstanceCount);
        if (moduleDescriptors[moduleName].moduleInstanceCount == 0 && moduleDescriptors[moduleName].style.linkElement) {
            moduleDescriptors[moduleName].style.linkElement.remove();
            moduleDescriptors[moduleName].style.status = 'undefined';
        }
    }

    ModuleManager.prototype = {
        constructor: ModuleManager, // restore constructor

        /**
         * Start module in element.
         * @param {element} element - dom element
         * @param {string} moduleName - module name
         * @param {string} jsFilePath - file path to js file with module definition
         * @return Promise
         */
        init: function (element, moduleName, jsFilePath) {
            //1. load file via RequireJs (reject promise on error)
            //2. register module - it means create and add moduleDescription
            //3. check if element doesn't contain module
            //4. create context - today it is proxy to element, event bus and global config
            //5. create instance of module
            //6. generate id for module
            //7. increase module counter (used for id and styles)
            //8. load styles (if styles is already in loading process then add handler and wait)
            //9. init module in style callback (if there is no styles it wil be called immediately)
            var self = this;

            var promise = new Promise(function (resolve, reject) {
                self._requireProxy.require(
                    [jsFilePath],
                    function (importModulesData) {
                        if (!self._moduleDescriptors[moduleName]) {
                            self.register(moduleName, importModulesData[moduleName]);
                        }

                        var moduleDescriptor = self._moduleDescriptors[moduleName];
                        var instanceId = element.getAttribute(MODULE_IN_ELEMENT_ID);
                        //this che is placed here because if we put it outside require callback module in this element may be inited concurrently
                        if (instanceId && moduleDescriptor.moduleInstances[instanceId]) {
                            throw new Error("Only one module per element supported. Please destroy it first."); //todo: reject promise
                        }

                        var moduleInstance = {};
                        moduleInstance.element = element;
                        moduleInstance.context = createContext(element, self.getEventBus(), self.getConfig());
                        moduleInstance.instance = moduleDescriptor.moduleFactory(moduleInstance.context);
                        instanceId = 'mod-' + moduleName + '-' + moduleDescriptor.moduleInstanceNewId;
                        element.setAttribute(MODULE_IN_ELEMENT_ID, instanceId);
                        moduleDescriptor.moduleInstanceNewId++;
                        moduleDescriptor.moduleInstances[instanceId] = moduleInstance;
                        moduleDescriptor.style.path = moduleDescriptor.style.path || moduleInstance.instance.styleSheet || null;
                        linkStyleSheet(moduleDescriptor, jsFilePath, function () {
                            moduleDescriptor.moduleInstanceCount++;
                            if (DEBUG) console.log("ModuleManager:moduleInstanceCount=" + moduleDescriptor.moduleInstanceCount);
                            moduleInstance.instance.init();
                            resolve();
                        });
                    },
                    function (error) {
                        reject(error);
                    }
                );
            });

            return promise;
        },

        /**
         * Register module.
         * Module factory function:
         * <code><pre>
         * function (context) {
         *     return {
         *         init: function,
         *         destroy: function
         *     }
         * }
         * </pre><code>
         * @param {string} moduleName - module name
         * @param {function} moduleFactory - create module function, see description above.
         */
        register: function (moduleName, moduleFactory) {
            if (this._moduleDescriptors[moduleName]) {
                throw new Error("Module with name '" + moduleName + "' already registered");
            }
            this._moduleDescriptors[moduleName] = {
                name: moduleName,
                moduleFactory: moduleFactory,
                style: {
                    path: null,
                    status: 'undefined',
                    handlers: [],
                    linkElement: null
                },
                moduleInstanceCount: 0,
                moduleInstanceNewId: 0,
                moduleInstances: {}
            }
        },

        destroyModule: function (element) {
            var instanceId = element.getAttribute(MODULE_IN_ELEMENT_ID);
            if (!instanceId) {
                throw new Error("Module id '" + MODULE_IN_ELEMENT_ID + "' not found");
            }
            for (var moduleName in this._moduleDescriptors) {
                destroyOneModule(this._moduleDescriptors, moduleName, instanceId);
            }
        },

        destroyAllModules: function () {
            for (var moduleName in this._moduleDescriptors) {
                for (var instanceId in this._moduleDescriptors[moduleName].moduleInstances) {
                    destroyOneModule(this._moduleDescriptors, moduleName, instanceId);
                }
            }
        },

        /**
         * @return {packageApi.EventBus}
         */
        getEventBus: function () {
            return this._eventBus;
        },

        getConfig: function () {
            return this._config;
        }
    };

    return ModuleManager;
}());