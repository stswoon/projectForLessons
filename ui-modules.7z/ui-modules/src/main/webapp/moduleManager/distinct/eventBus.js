var packageApi = packageApi || {};
packageApi.EventBus = (function () {
    function EventBus() {
        this._handlers = {};
    }

    EventBus.prototype = {
        constructor: EventBus, // restore constructor

        /**
         * Add handler to all 'type' events
         * Storage Structure:
         * allHandlers =
         * {
         *     'type1':[handler11, handler12],
         *     'type2':[handler21]
         * }
         * Duplicated handlers wont be added
         * @param type type of event
         * @param handler function executed on event with {@param type}
         * @returns {{remove: remove}} object with remove() method can be used to unsubscribe handler
         */
        on: function (type, handler) {
            var handlers = this._handlers[type],
                i,
                len;

            if (typeof handlers === 'undefined') {
                handlers = this._handlers[type] = [];
            }

            for (i = 0, len = handlers.length; i < len; i++) {
                if (handlers[i] === handler) {
                    // prevent duplicate handlers
                    return;
                }
            }

            handlers.push(handler);
            return {
                remove: function () {
                    var index = handlers.indexOf(handler);
                    if (index > -1) {
                        handlers.splice(index, 1);
                        return true;
                    }
                    return false;
                }
            }
        },

        /**
         * Global firing of event with {@param type} and some data. All handlers will receive event object like
         * {
         *      'type': '<type>',
         *      'data': '<data>'
         * }
         * @param type type of event to fire
         * @param data any data object will be send to all handlers
         */
        fire: function (type, data) {
            var handlers,
                i,
                len,
                event = {
                    type: type,
                    data: data
                };

            handlers = this._handlers[event.type];
            if (handlers instanceof Array) {
                //@NOTE: concurrent modification
                handlers = handlers.concat();
                for (i = 0, len = handlers.length; i < len; i++) {
                    handlers[i].call(this, event);
                }
            }
        },

        /**
         * Unsubscribes handler or handlers by type.
         * If handler equals to some registered handler than it will be deleted.
         * If handler not found than nothing will be deleted.
         * If handler equals to 'undefined' than all handlers by type will be deleted.
         * @param type event type
         * @param handler handler or undefined
         */
        off: function (type, handler) {
            var handlers = this._handlers[type],
                i,
                len;

            if (typeof handler === 'undefined') {
                delete this._handlers[type];
                return;
            }

            if (handlers instanceof Array) {
                for (i = 0, len = handlers.length; i < len; i++) {
                    if (handlers[i] === handler) {
                        handlers.splice(i, 1);
                        break;
                    }
                }
            }
        }
    };

    return EventBus;
}());