//todo:!!! R is WA, see requireWrap.js, so check in future for webpack, maybe provide umd wrap for custom dynamic modules and for ModuleManager
(function() {
    //###insertRequireJS###



    var R = {};
    R.requirejs = requirejs;
    R.require = require;
    R.define = define;
    window.R = R;
})();