/**
 * Create filter to check if static module has access
 * @example
 * <code>
 *     <div ng-if="'Static Module Name' | checkStaticModuleAccess">My Static Module</div>
 * </code>
 * @param {moduleManagerFactory} moduleManagerFactory
 * @return {filter} {@link filter}
 */
function staticModuleAccessFilterFactory(moduleManagerFactory) {
    'use strict';

    /**
     * Return boolean access flag about static module.
     * @param {string} moduleName name of static module
     * @return {boolean} true if module has access and exist in moduleManagerFactory or false.
     */
    function filter(moduleName) {
        return moduleManagerFactory.isStaticModuleAccess(moduleName, "instant");
    }

    filter.$stateful = true; //important according to http://stackoverflow.com/a/27771259/7860797 and https://egghead.io/lessons/angularjs-stateful-filters-with-promises-in-angularjs

    return filter;
}