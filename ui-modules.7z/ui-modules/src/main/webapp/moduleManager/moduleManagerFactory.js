/**
 * Create moduleManagerFactory instance
 * @param loginFactory - with getTenantDNS() and onTenantDNSChange() methods
 * @param restServiceFactory - with webResources and uiConfigurationModules consts
 */

function moduleManagerFactory($http, $rootScope, $q, loginFactory, restServiceFactory) {
    var DEBUG = false;

    var modulesData = {};
    var fetchingPromise = $q(function(resolve, reject){reject(new Error("Tenant not specified"))});
    var staticModuleAccessHandlerInfos = [];
    var moduleManager = null;

    var api = {};

    /**
     * Create new {@link ModuleManager}. If ModuleManager already exist then it will be destroyed first.
     * @param config global config for ModuleManager
     */
    api.initDynamicModuleManager = function (config) {
        if (moduleManager) {
            moduleManager.destroyAllModules();
        }
        moduleManager = new ModuleManager(config || {});
    };

    /**
     * Proxy to {@link ModuleManager#getConfig}
     */
    api.getDynamicModuleConfig = function () {
        return moduleManager.getConfig();
    };

    /**
     * Proxy to {@link ModuleManager#getEventBus}
     */
    api.getDynamicModuleEventBus = function () {
        return moduleManager.getEventBus();
    };

    /**
     * Init module via proxy call to {@link ModuleManager#init} only after modules data loaded.
     * @param {element} element to insert module
     * @param {string} moduleName module name
     * @return {ngPromise} call success callback or return error in error callback.
     */
    api.initDynamicModule = function (element, moduleName) {
        var initModuleError = new Error("Error to load module '" + moduleName + "'");
        var promise = $q(function (resolve, reject) {
            fetchingPromise.then(function success() {
                if (!modulesData[moduleName] || modulesData[moduleName].type != "dynamic") {
                    reject(initModuleError);
                    return;
                }

                moduleManager.init(element, moduleName, restServiceFactory.webResources + modulesData[moduleName].path)
                    .then(function success() {
                        resolve();
                    }, function error(cause) {
                        reject(cause);
                    });
            }, function error() {
                reject(initModuleError);
            });
        });
        return promise;
    };

    /**
     * Proxy to {@link ModuleManager#destroyModule}
     */
    api.destroyDynamicModule = function (element) {
        moduleManager.destroyModule(element);
    };

    /**
     * Proxy to {@link ModuleManager#destroyAllModules}
     */
    api.destroyAllDynamicModules = function () {
        moduleManager.destroyAllModules();
    };

    /**
     * Same as {@link isAccess} but works only for static modules
     */
    api.isStaticModuleAccess = function (moduleName, workType, handler) {
        return isAccess(isStaticModuleAccessInstant, moduleName, workType, handler);
    };

    /**
     * Same as {@link isAccess} but works only for dynamic modules
     */
    api.isDynamicModuleAccess = function (moduleName, workType, handler) {
        return isAccess(isDynamicModuleAccessInstant, moduleName, workType, handler);
    };

    /**
     * Check and return access flag for static modules.
     *
     * There are 3 working approaches: "promise" (default), "instant", "handler".
     * isStaticModuleAccess(<moduleName>, "instant") return boolean immediately - ussualy used for internal purpose
     * isStaticModuleAccess(<moduleName>, "promise") or isStaticModuleAccess(<moduleName>) return boolean angular promise
     * isStaticModuleAccess(<moduleName>, "handler", function(flag) {}) return object with remove() method to remove handler
     * and function in third parameter will be call on any change of data. More convenient way is to use staticModuleAccessFilter.
     *
     * @param isAccessInstant function to check access immediatelly
     * @param moduleName name of static module to check access
     * @param workType change type of return value and algorithm to get result
     * @param handler for workType=="handler"     *
     * @return boolean | angular-promise | handlerRemover
     */
    function isAccess(isAccessInstant, moduleName, workType, handler) {
        if (workType && workType === "instant") {
            return isAccessInstant(moduleName);
        } else if (workType && workType === "handler") {
            staticModuleAccessHandlerInfos.push({
                moduleName: moduleName,
                handler: handler
            });

            handler(isAccessInstant(moduleName));

            var index = staticModuleAccessHandlerInfos.length - 1;

            function createRemover(index) {
                return {
                    remove: function () {
                        staticModuleAccessHandlerInfos.splice(index, 1);
                    }
                }
            }

            return createRemover(index);
        } else {
            var promise = $q(function (resolve, reject) {
                fetchingPromise.then(function success() {
                    resolve(isAccessInstant(moduleName));
                }, function error() {
                    reject(new Error("Error to load modules data for tenant"));
                });
            });
            return promise;
        }
    };

    function isStaticModuleAccessInstant(moduleName) {
        var module = modulesData[moduleName];
        if (module && module.type === "static") {
            return module.access;
        } else {
            return false;
        }
    }

    function isDynamicModuleAccessInstant(moduleName) {
        var module = modulesData[moduleName];
        return module ? true : false;
    }

    function callStaticModuleAccessHandlers() {
        for (var i = 0; i < staticModuleAccessHandlerInfos.length; ++i) {
            var flag = isStaticModuleAccessInstant(staticModuleAccessHandlerInfos[i].moduleName);
            staticModuleAccessHandlerInfos[i].handler(flag);
        }
    }

    function parseModulesDataResponse(response) {
        for (var i = 0; i < response.data.length; ++i) {
            modulesData[response.data[i].name] = response.data[i];
        }
    }

    var fetchingPromiseLastId = null;

    function init() {
        loginFactory.onTenantDNSChange(function (data) {
            modulesData = {};
            callStaticModuleAccessHandlers();
            $rootScope.$emit('moduleManagerFactory:modulesDataChanging');
            if (data.tenantDNS) {
                fetchingPromiseLastId = (new Date()).getTime();
                (function makeRequest(fetchingId) {
                    fetchingPromise = $http.get(restServiceFactory.uiConfigurationModules + "/" + loginFactory.getTenantDNS()).then(
                        function success(response) {
                            if (fetchingPromiseLastId != fetchingId) {
                                if (DEBUG) console.log("moduleManagerFactory:skip old request");
                                return;
                            }
                            if (DEBUG) console.log("moduleManagerFactory:loadModules-Success:response=", response);
                            parseModulesDataResponse(response);
                            callStaticModuleAccessHandlers();
                            $rootScope.$emit('moduleManagerFactory:modulesDataChanged');
                        },
                        function error(response) {
                            if (fetchingPromiseLastId != fetchingId) {
                                if (DEBUG) console.log("moduleManagerFactory:skip old request");
                                return;
                            }
                            if (DEBUG) console.error("moduleManagerFactory:loadModules-Fail:response=", response);
                            console.error("Error to load modules data for tenant '" + data.tenantDNS + "'. Response=", response);
                        }
                    );
                })(fetchingPromiseLastId);
            }
        });
    }

    init();

    return api;
}