## Module Manager - dev docs

### moduleManagerFactory
It's facade which consists of several parts:

1. loading data about available modules for tenant
2. provide api to check access for static and dynamic modules
3. provide proxy method to moduleManager
4. decorate moduleManager's init module function

#### isAccess
A bit complex function because it contains 3 behaviours.

Behaviour **instant** simple check `modulesData` param.

Behaviour **promise** check `modulesData` param but only after resolution of `fetchingPromise`.

Behaviour **handler** register handler and return handler registration.
Then handler check `modulesData` param only after resolution of `fetchingPromise`.
If tenant changes generates new `fetchingPromise` handlers will calls after resolution of new promise.

#### initDynamicModule
Call ModuleManager#init after resolution of `fetchingPromise` and if dynamic module exists. Return ngPromise.

#### init
Register handler via `loginFactory.onTenantDNSChange` to observe tenant change.

If tenant is null than clear `modulesData`, call handlers, fire event.

If tenant is filled than crate promise with some unique id. After got response check ids
to avoid old response in case of several fast changing. Than fill `modulesData`, call handlers, fire event.

### staticModuleAccessFilterFactory
Algorithm:
Ask moduleManagerFactory about **static** module access with direct instant call without promises and callbacks.
Than it specifies `$stateful = true` to be checked on every angular loop according to literature from
links below.

Analysis:

1. http://stackoverflow.com/a/27771259/7860797
2. https://egghead.io/lessons/angularjs-stateful-filters-with-promises-in-angularjs
3. https://github.com/angular-translate/angular-translate/blob/master/src/filter/translate.js

### requireWrap
Wrapper for [RequireJs](http://requirejs.org/) which provide global parameter `R` with proxy api
* R#require
* R#define

It's needed because angularJs already has own require\define functions which works different way.

It works pretty simple. We wrap all RequireJs code inside function and return `R`. To insert code
used `gulp-replace` for hand-made macros `//###insertRequireJS###` in file
```javascript
(function() {
    //###insertRequireJS###
    ...
    window.R = R;
})();
```
:exclamation: Seems we need develop umd wrap

### moduleManager
It's based on [Scalable JS Apps](https://code.tutsplus.com/tutorials/writing-modular-javascript--net-14746)
principals told by Nicholas C. Zakas. The main realization of this principals is [t3js](http://t3js.org/).
But we modified t3js in [prototype](https://svn.netcracker.com/orgux/UI%20Framework%20research/umbrella-project/umbrella-modularjs)
a lot for additional [NC requirements](https://bass.netcracker.com/pages/viewpage.action?pageId=424442552).

But for current project developed only little functionality for more info about requirement and api
see [analysis](https://bass.netcracker.com/pages/viewpage.action?spaceKey=UX&title=%5BDRAFT%5D+Umbrella+Module+Loading).

#### Build
Module Manager consists today for two files:

1. eventBus.js
2. moduleManager.js

Splitting on two files help to avoid large files. Because we use gulp without webpack we
was needed to invent semi-modules. It's achieved via params `packageApi` (collects all api without publication),
`publicApi` (collects api to be public, ike export), `gulp-concat` and `gulp-wrap` with wrapper
```javascript
(function() {\n<%= contents %>\n return window.ModuleManager = publicApi.ModuleManager; \n}());
```
:exclamation: Seems we need develop umd wrap

At the end we get moduleManager.js bundle.

#### Polyfills
It uses:

1. Polyfill for promise for ie11 ([link](https://github.com/then/promise))

#### Deps
Module Manager load file via [RequireJs](http://requirejs.org/). So you need to link require.js to
have require\define in window scope or you should have `R` object (see 'requireWrap' section) with
methods require\define or you can set it in config in constructor. But because of angularJs you need to
use requireWrap WA. Also because of angularJs all modules in definition use `R` symbol instead of common
`define`.

#### Linking
You can link require.js\requireWrap.js and moduleManage.js before main.js bundle or you can compile
files in bundle.

#### EventBus
Standard EventBus pattern with handler remover.

#### Module definition
WA - using R (see 'requireWrap' section)

#### Module init
Algorithm:

1. load file via RequireJs (reject promise on error)
2. register module - it means create and add moduleDescription
3. check if element doesn't contain module
4. create context - today it is proxy to element, event bus and global config
5. create instance of module
6. generate id for module
7. increase module counter (used for id and styles)
8. load styles (if styles is already in loading process then add handler and wait)
9. init module in style callback (if there is no styles it wil be called immediately)

:exclamation: maybe use [RequireCss](https://github.com/guybedford/require-css) for style loading

Sequence diagram of Module Loading:

![ModuleLoading](diagrams/ModuleLoading.jpg)

#### Module destroy
Algorithm:

1. get instance id from element attr
2. call destroy method of module
3. clear html in element
4. remove instance from `_moduleDescriptors`
5. if there is no other instances of this module than remove style link

#### Future features
There are a lot of features to be done:
1. Dependencies
2. semi-DI
3. UMD
4. Error handling
5. JS file bundling and prediction js files to load depend on deps
6. ESLint to prevent rules of scalableJs approach violation

