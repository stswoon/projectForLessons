## Module Manager
This functionality support using static or dynamic modules.

### Module Configuration
To configure list of modules per tenant see [ui-configuration-service](https://git.netcracker.com/DEMO.Platform.Saas_Cloud_Catalog/ui-configuration-service)

### Static Modules
Static Module is a module (some part of code and view) compiled with end application but it should be displayed
according to some property, e.g. according to `tenantDNS` parameter.

#### Import
To make it work:
* import filter and factory
```javascript
angular.module("app").filter("moduleManagerFactory", moduleManagerFactory);
angular.module("app").factory("checkStaticModuleAccess", staticModuleAccessFilterFactory);
```
* add rest url in `restServiceFactory`
```javascript
service.uiConfigurationModules = service.ip + "/api/v1/ui-configuration/modules-provider";
service.webResources = service.ip + '/api/v1/ui-configuration/web-resource';
```

#### Usage
Usually module is an angular element so you can use filter
```javascript
<div ng-if="'Static Module Name' | checkStaticModuleAccess">My Static Module</div>
```

Also you can use service api
```javascript
moduleManagerFactory.isStaticModuleAccess("Static Module")
    .then(function (flag) { //true or false
        console.log(flag);
    });
```
Pay attention that promise resolves only once so after change `tenantDNS` you should call
`moduleManagerFactory#isStaticModuleAccess` again to get new promise. Another way
to solve this is to register handler
```javascript
var remover = moduleManagerFactory
    .isStaticModuleAccess("Static Module", "handler",
        function (flag) {
            console.log(flag);
        }
    );
...
remover.remove(); //call it if you don't need hanler more
```

### Dynamic Modules
Dynamic module is a js + css code that can be injected independent in some dom element.

It's based on [Scalable JS Apps](https://code.tutsplus.com/tutorials/writing-modular-javascript--net-14746)
principals told by Nicholas C. Zakas. The main realization of this principals is [t3js](http://t3js.org/).
But we modified t3js in prototype a lot for additional [NC requirements](https://bass.netcracker.com/pages/viewpage.action?pageId=424442552).

#### Import
To make it work:
* import factory
```javascript
angular.module("app").factory("moduleManagerFactory", moduleManagerFactory);
```
* add rest url in `restServiceFactory`
```javascript
service.uiConfigurationModules = service.ip + "/api/v1/ui-configuration/modules-provider";
service.webResources = service.ip + '/api/v1/ui-configuration/web-resource';
```
* add additional js files to build
```javascript
//somewhere in gulp config
"bower_components/es6-promise/es6-promise.min.js",
"bower_components/ui-modules/moduleManager/distinct/requireWrap.js",
"bower_components/ui-modules/moduleManager/distinct/moduleManager.js",
```

#### Usage
##### Init
Init moduleManager somewhere, e.g. in `InitController` for `initState`:
```javascript
moduleManagerFactory.initDynamicModuleManager({
    gateway: restServiceFactory.ip
    //you can specify in config any params even angular app
});
```

##### Start Module
```javascript
var element = document.getElementById("placeholder");
var moduleName = "nc.test.helloWorld";
moduleManagerFactory.initDynamicModule(element, moduleName);
```
or
```javascript
moduleManagerFactory.initDynamicModule(element, moduleName).then(
    function success() {...},
    function error(error) {...}
);
```
##### Stop Module
```javascript
var element = document.getElementById("placeholder");
moduleManagerFactory.destroyDynamicModule(element);
```
or
```javascript
moduleManagerFactory.destroyAllDynamicModules();
```
##### Subscribing
```javascript
moduleManagerFactory.getDynamicModuleEventBus()
    .on("moduleInit", function (event) {
        console.log(event.data.message);
});
```

#### Module Definition
To define module you should use specific format and rules.

Today rules are not strict because it's first implementation. From Scalable JS Apps approach
we leave only two rules:
* clean for yourself - it means you should destroy all dom element, js objects, css styles
after finish of your module. If you skip this rule it may shoot in future as memory leaks.
* operate only with your own element - it means you should operate only form element from context.
If you skip this rule it may provoke situation when your module broke ather dom elements so other
modules or whole application cannot work.

Format
```javascript
//R - wrapper for requirejs
R.define(function () {
    var exportData = {
        "moduleName": function (context) {
            return {
                styleSheet: {string}
                init: {function}
                destroy: {function}
            }
        }
    };
    return exportData;
});
```
`R` is wrapper for requireJs because normal names `require` and `define` clashes with angularJs
(for more info see [dev docs](/src/main/webapp/moduleManager/docs))

Example
```javascript
//R - wrapper for requirejs
R.define(function () {
    var exportData = {
        "nc.test.helloWorld": function (context) {
            return {
                styleSheet: "simpleModule.css", //path relative to file of this module
                init: function () {
                    context.getElement().innerHTML = "<span class='red'>Hello World!</span>";
                },
                destroy: function () {
                    context.getElement().innerHTML = "";
                }
            }
        }
    };
    return exportData;
});
```

You can use functionality of context
```javascript
context.getEventBus().fire("moduleInit", {message: "Hello!"}); //events
console.log("gateway from config: " + context.getConfig().gateway); //global config
```
You can do whatever you want in your module, e.g. call ajax, fire and handle events from other modules,
use reactJs ar others frameworks.

##### AngularJs WA
AngularJs doesn't provide ability to insert another angular application in any dom element inside
application. So for case of dynamic angular application you can use
[Angular Dynamization](/src/main/webapp/angularDynamization) approach.

Example
```javascript
R.define(function () {
    var exportData = {
        "nc.test.ngInNg": function (context) {
            return {
                init: function () {
                    angular.module('app').startDynamicRegistration();
                    context.getElement().innerHTML = "<hello-User-Component></hello-User-Component>";
                    angular.module('app')
                        .component('helloUserComponent', {
                            template:
                            "<div>" +
                            "Hello User Component </br>" +
                            "<input ng-model='name' ng-keyup='NameChange()'>" +
                            "<h1>{{greeting}}</h1>" +
                            "</div>",
                            controller: function HelloUserController($scope) {
                                $scope.NameChange = function () {
                                    $scope.greeting = "Hello " + $scope.name;
                                };
                            }
                        });
                    angular.module("app").stopDynamicRegistration(context.getElement());
                },
                destroy: function () {
                    context.getElement().innerHTML = "";
                }
            }
        }
    };
    return exportData;
});

```

### Require Wrapper
Wrapper for [RequireJs](http://requirejs.org/) which provide global parameter `R` with proxy api
* R#require
* R#define

It's needed because angularJs already has own require\define functions which works different way.

### Dev docs
See also - [link](/src/main/webapp/moduleManager/docs)