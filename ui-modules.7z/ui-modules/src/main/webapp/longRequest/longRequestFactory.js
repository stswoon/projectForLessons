/**
 * @param poller https://github.com/emmaguo/angular-poller
 * @return LongRequestFactory with method create()
 */
function longRequestFactory($q, $http, poller) {
    var debug = false; //ability to print debug logs

    /**
     * Add prefix for before url if it doesn't contains protocol (like http(s)://)
     * @param prefix to add
     * @param url to be modified
     */
    function addUrlPrefix(prefix, url) {
        //indexOf()!=0 instead of startWith() because of IE
        if (prefix && url.indexOf("http") != 0) {
            //maybe add check on doubling '\'
            return prefix + url;
        }
        return url;
    }

    /**
     * Client side helper with provide ability to start long server action (e.g. 5+ min),
     * check progress and return result.
     */
    var LongRequest = function () {
        this._config = null;
        this._longRequestPoller = null;

        /**
         * Config can be simple URL for get request or java script object like
         * <code><pre>
         * config: {
         *    method: string
         *    url: string
         *    params: Object<string:Object> // https://docs.angularjs.org/api/ng/service/$httpParamSerializer
         *    data: string|Object
         *    headers: Object<string:string> //like {Accept: "application/json; charset=utf-8", "Content-Type": "text/plain; charset=utf-8"}
         *    resultHeaders: Object<string:string> //same as headers
         *
         *    urlPrefix: string //prefix for every url below if they doesn't contains protocol (like http(s)://)
         *    progressUrl: string
         *    resultUrl: string
         *    terminateUrl: string //optional url
         * }
         * </pre></code>
         *
         * Params method, url, params, data, headers are the same as in https://docs.angularjs.org/api/ng/service/$http.
         *
         * Params progressUrl, resultUrl, terminateUrl are url to check progress, get result and terminate long server action.
         * These urls are not required because they can be returned from server automatically after first request to back
         * to start long server action but it may happen that back server didn't return it but provide them in docs so you can
         * specify urls before request sending.
         *
         * If urls doesn't contains protocol than automatically protocol of current page will be used. For progressUrl,
         * resultUrl, terminateUrl it's possible to set urlPrefix to use it instead of protocol of current page.
         *
         * @param config: string | {}
         */
        this.init = function (config) {
            if (!config) {
                throw new Error("'config' param should not be empty");
            }
            if (typeof config === "string") {
                this._config = {
                    method: 'GET',
                    url: config,
                    headers: {Accept: "application/json; charset=utf-8"}
                };
            } else {
                this._config = config;
                if (!this._config.headers) {
                    this._config.headers = {Accept: "application/json; charset=utf-8"};
                } else if (this._config.headers && !this._config.headers.Accept) {
                    this._config.headers.Accept = "application/json; charset=utf-8";
                }
            }
        };

        /**
         * Start long request and return angular promise with success and error callbacks:         *
         * - successCallback: function(response)
         * - errorCallback: function(response | Error)
         * According to https://docs.angularjs.org/api/ng/service/$http response status 200-299 is success other statuses is error.
         * Example:
         * <code><pre>
         *     var longRequest = longRequestFactory.create();
         *     longRequest.init("/buildReport?id=123");
         *     longRequest.send().then(function (response) {
         *          console.log("Success:", response.data);
         *     }, function (response) {
         *          if (response instanceof Error) throw response
         *          console.log("Fail:", response.data);
         *     });
         * </pre></code>
         *
         * @return Function function - angular promise with success and error callbacks (similar to $http)
         */
        this.send = function () {
            var self = this;

            /**
             * resolve\reject from angular promise
             * progressResponse - json response from last progress request which may contains result url
             */
            var resultExecution = function (resolve, reject, progressResponse) {
                self._config.resultUrl = self._config.resultUrl ? self._config.resultUrl : progressResponse.data.resultUrl;
                if (!self._config.resultUrl) {
                    if(debug) console.log("LongRequest:resultRequest: reject because resultUrl is not specified");
                    self._longRequestPoller.stop();
                    reject(new Error("resultUrl is not specified"));
                }
                this.resultRequestConfig = {
                    method: 'GET',
                    url: addUrlPrefix(self._config.urlPrefix, self._config.resultUrl),
                    headers: self._config.resultHeaders || {}
                };
                $http(resultRequestConfig).then(
                    function successCallback(response) {
                        if(debug) console.log("LongRequest:resultRequest-Success:response=", response);
                        resolve(response);
                    },
                    function errorCallback(response) {
                        if(debug) console.log("LongRequest:resultRequest-Fail:response=", response);
                        reject(response);
                    }
                );
            };

            /**
             * resolve\reject from angular promise
             * startResponse - json response from start request with may contains urls for:
             * progress, result, terminate
             */
            var progressExecution = function (resolve, reject, startResponse) {
                self._config.progressUrl = self._config.progressUrl || startResponse.data.progressUrl;
                self._config.resultUrl = self._config.resultUrl || startResponse.data.resultUrl;
                self._config.terminateUrl = self._config.terminateUrl || startResponse.data.terminateUrl;

                var progressUrl = self._config.progressUrl ? self._config.progressUrl : startResponse.data.progressUrl;
                if (!progressUrl) {
                    if(debug) console.log("LongRequest:progressRequest: reject because progressUrl is not specified");
                    reject(new Error("progressUrl is not specified"));
                }
                if(debug) console.log("LongRequest:progressRequest:starting");
                self._longRequestPoller = poller.get(addUrlPrefix(self._config.urlPrefix, progressUrl), {catchError: true});
                self._longRequestPoller.promise.then(null, null, function (response) {
                    if(debug) console.log("LongRequest:progressRequest:response=", response);

                    //similar if as in https://docs.angularjs.org/api/ng/service/$http, in short:
                    //response status 200-299 is success other statuses is error
                    if (200 <= response.status && response.status <= 299) {
                        if (response.data.status === "progress") {
                            //nothing
                        } else if (response.data.status === "fail") {
                            if(debug) console.log("LongRequest:progressRequest:reject");
                            self._longRequestPoller.stop();
                            reject(response);
                        } else if (response.data.status === "done") {
                            if(debug) console.log("LongRequest:progressRequest:goToResult");
                            self._longRequestPoller.stop();
                            resultExecution(resolve, reject, response);
                        }
                    } else {
                        if(debug) console.log("LongRequest:progressRequest:reject");
                        self._longRequestPoller.stop();
                        reject(response);
                    }
                });
            };

            if (self.sendPromise) {
                if (debug) console.log("LongRequest:use already created sendPromise");
            } else {
                self.sendPromise = $q(function (resolve, reject) {
                    if (debug) console.log("LongRequest:config", self._config);
                    var requestConfig = {
                        method: self._config.method,
                        url: self._config.url,
                        params: self._config.params,
                        data: self._config.data,
                        headers: self._config.headers,
                    };
                    $http(requestConfig).then(
                        function successCallback(response) {
                            if (debug) console.log("LongRequest:startRequest-Success:response=", response);
                            progressExecution(resolve, reject, response);
                        },
                        function errorCallback(response) {
                            if (debug) console.log("LongRequest:startRequest-Fail:response=", response);
                            reject(response);
                        }
                    );
                });
            }
            return self.sendPromise;
        };

        /**
         * Terminate checking progress. First stop client and then send request to terminate server action if terminateUrl exist.
         * @param onlyClient if true only cancel checking progress from client
         * @return angular promise
         */
        this.terminate = function (onlyClient) {
            this._longRequestPoller.stop();
            if (!onlyClient) {
                if (this._config.terminateUrl) {
                    var requestConfig = {
                        method: 'POST',
                        url: addUrlPrefix(this._config.urlPrefix, this._config.terminateUrl)
                    };
                    return $http(requestConfig);
                }
            }
        }

        //To be done in future: add ability to specify all options
        //- for first and finish request (like https://docs.angularjs.org/api/ng/service/$http#usage)
        //- options for poller (https://github.com/emmaguo/angular-poller).
        //- transition between first - progress  - finish, e.g. ability to set callback which convert response from start request to progress request,
        //  where progress options can contain macros (like {actionId})
        //Config example:
        // config = {startRequestConfig, converterFunc, pollingConfig, converterFunc, resultRequestConfig}
        // this.advancedInit = function(config) {
        //     this.advancedConfig = true;
        //     this._config = config;
        // };
    };


    var factory = {};
    /**
     * Return LongRequest
     * @return {LongRequest}
     */
    factory.create = function () {
        return new LongRequest();
    };
    return factory;
}