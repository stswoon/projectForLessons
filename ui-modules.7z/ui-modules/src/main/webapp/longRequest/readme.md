## Long Request - Dev docs
Client side helper with provide ability to start long server action (e.g. 5+ min), check progress and return result.
Also it is able to terminate long server action

### Usage
##### Import
```javascript
angular.module("app", [..., 'emguo.poller'])
angular.module("app").factory("longRequestFactory", longRequestFactory);
function yourController(longRequestFactory) {
    //send long request
}
```
##### Start request
Simple usage example
```javascript
var longRequest = longRequestFactory.create();
//generate report for some object with id which may take 3+ min
longRequest.init("/buildReport?id=123");
longRequest.send().then(function (response) {
    // process response, e.g. suggest user to download data as file
    // or show message with link to file
}, function (response) {
    console.log("Failed to finish long request. Cause is ", response.data);
});
```
Method `longRequest.send().then()` return standard angular promise and works similar to `$http.then()`.
So it means that you can set several callback on `send()` method but only one request will be send to server,
result response will be cached and used for callbacks.

Link to start long request should be provided by some server-side-controller which supports contract
of this long request approach. See contract in section [server-side contract](#server-side contract).

##### Post
Another common case is to send some post data and then get result in appropriate type.
```javascript
var longRequest = longRequestFactory.create();
longRequest.init({
    method: 'POST',
    url: "/startLongServerAction",
    data: {message: "Test data from client", version: 1},
    resultHeaders: {Accept: "text/plain"}
});
longRequest.send().then(function (response) {
    // process response
});
```

Parameter `resultHeaders` is an ability to specify headers for request which will return result of long server action.

##### API
<table>
    <thead>
        <tr>
            <th>Entity</th>
            <th>Method</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>longRequestFactory</td>
            <td>create</td>
            <td>Return LongRequest</td>
        </tr>
        <tr>
            <td>LongRequest</td>
            <td>constuctor</td>
            <td>Create class</td>
        </tr>
        <tr>
            <td>LongRequest</td>
            <td>init</td>
            <td>
Config can be simple URL for get request or java script object like
<code><pre>
config: {
   method: string
   url: string
   params: Object<string:Object> // https://docs.angularjs.org/api/ng/service/$httpParamSerializer
   data: string|Object
   headers: Object<string:string> //like {Accept: "application/json; charset=utf-8", "Content-Type": "text/plain; charset=utf-8"}
   resultHeaders: Object<string:string> //same as headers
   urlPrefix: string //prefix for every url below if they doesn't contains protocol (like http(s)://)
   progressUrl: string
   resultUrl: string
   terminateUrl: string
}
</pre></code>

Params method, url, params, data, headers are the same as in https://docs.angularjs.org/api/ng/service/$http.
<br/>
Params progressUrl, resultUrl, terminateUrl are url to check progress, get result and terminate long server action.
These urls are not required because they can be returned from server automatically after first request to back
to start long server action but it may happen that back server didn't return it but provide them in docs so you can
specify urls before request sending.
<br/>
If urls doesn't contains protocol than automatically protocol of current page will be used. For progressUrl,
resultUrl, terminateUrl it's possible to set urlPrefix to use it instead of protocol of current page.
            </td>
        </tr>
        <tr>
            <td>LongRequest</td>
            <td>send</td>
            <td>
Start long request and return angular promise with success and error callbacks:
<br/>
- successCallback: function(response)
<br/>
- errorCallback: function(response | Error)
<br/>
According to https://docs.angularjs.org/api/ng/service/$http response status 200-299 is success other statuses is error.
<br/>
Example:
<code><pre>
var longRequest = longRequestFactory.create();
longRequest.init("/buildReport?id=123");
longRequest.send().then(function (response) {
     console.log("Success:", response.data);
}, function (response) {
     if (response instanceof Error) throw response
     console.log("Fail:", response.data);
});
</pre></code>

@return Function function - angular promise with success and error callbacks (similar to $http)
            </td>
        </tr>
        <tr>
            <td>LongRequest</td>
            <td>terminate</td>
            <td>
Terminate checking progress. First stop client and then send request to terminate server action if terminateUrl exist.
<br/>
Param 'onlyClient' if true only cancel checking progress from client
<br/>
Return angular promise
            </td>
        </tr>
    </tbody>
</table>

##### Server-side contract
Server rest-controller should have some rest-point:

1. start - to start long server action
2. progress - to check progress of action
3. result - to get result after end of action
4. terminate - to terminate action

Assumptions
* Urls for these rest-point may belong to one controller or to several.
* Terminate end-point is optional.
* All urls may have same url but rest-controller some-how should distinguish them, e.g. special parameter mode

<table>
    <thead>
        <tr>
            <th>Rest-point</th>
            <th>Request</th>
            <th>Response - success</th>
            <th>Response - fail</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>start</td>
            <td>
                Accept-Type: json
                <br/>
                Other request headers can be specified as init param.
            </td>
            <td>
Content-Type: json
<br/>
Code: from 200 to 299
<code><pre>
{
   progressUrl: string //required if it is not provided as
                       //init param for LongRequest
   resultUrl: string //optional
   terminateUrl: string //optional
}
</pre></code>
progressUrl should contains url to check progress, e.g /checkProgress?actionId=1493282268961
            </td>
            <td>Code: any other code than 200-299</td>
        </tr>
        <tr>
            <td>progress</td>
            <td>
                Type: GET
                <br/>
                Accept-Type: json
            </td>
            <td>
Content-Type: json
<br/>
Code: from 200 to 299
<code><pre>
{
   status: "progress" | "fail" | "done";
   resultUrl: string //required for "done" status
                      //if it is not provided as
                      //init param for LongRequest
                      //and not provided from start response
}
</pre></code>
resultUrl should contains url to get result, e.g /getResult?resultId=1493282675441
            </td>
            <td>Code: any other code than 200-299</td>
        </tr>
        <tr>
            <td>result</td>
            <td>
                Type: GET
                <br/>
                Request headers can be specified as init param.
            </td>
            <td>Code: from 200 to 299</td>
            <td>Code: any other code than 200-299</td>
        </tr>
        <tr>
            <td>terminate</td>
            <td>
                Type: POST
                <br/>
                url example: /terminate/e18dcd35-9ad8
            </td>
            <td>Code: from 200 to 299</td>
            <td>Code: any other code than 200-299</td>
        </tr>
    </tbody>
</table>

##### Dev docs
See [link](/src/main/webapp/longRequest/docs)