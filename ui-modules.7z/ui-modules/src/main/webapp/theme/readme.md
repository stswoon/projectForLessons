# Theme - Docs
Client side helper with provide ability to enable/disable (link/unlink) custom css styles for app

## Requirements
1. Add ability to add a theme by tenant DNS
2. Add ability to remove a theme
3. Only one theme can be linked at a time
4. Should have an ability to specify linked theme by a css class
5. Theme switching should has modes
 * Theme switching should be invisible for an end user
 * Theme switching can be executed without hiding of an entire app
6. Add ability to load a theme per tenant and per frontend

## Usage

### Import
```javascript
angular.module("app").factory("themeFactory", themeFactory);
```

### Prerequisites
App should registers factory with name `restServiceFactory` provides 2 constants:
* restServiceFactory.theme - url provides path for tenant theme. It should contains params {tenantDNS} and optionally {frontendName}, e.g. `/load-theme/{tenantDNS}/{frontendName}`
* restServiceFactory.webResources - url for web resource will be used to link styles in `<head>` element

### Load theme example
Call to load theme
```javascript
function yourController(themeFactory) {
    themeFactory.loadTheme(tenantDNS, hideBodyOrNo);
}
```

After theme is attached, `body` element will has specific style class to manage app styles *theme-tenantDNS*, where tenantDNS - tenantDNS that was used to load theme with themeFactory.loadTheme(...) 
 ```html
  <body class="theme-<tenantDNS>">
  ...
  </body> 
```

### Remove theme example
```javascript
function yourController(themeFactory) {
    themeFactory.removeTheme();
}
```

###
Set frontend name
```javascript
themeFactory.setFrontendName(frontendName);
```


## Dev docs
See [link](/src/main/webapp/theme/docs)