function themeFactory($document, $q, $http, restServiceFactory) {
    var api = {};
    var removers = [];
    var currentTenantDNS;
    var $body = angular.element('body');
    var frontendName;
    var faviconName = 'favicon.png';

    /**
     * Specify frontend application name to get more specific theme if it exists
     * @param {string} name frontend application name
     */
    api.setFrontendName = function (name) {
        frontendName = name;
    };

    /**
     * Loads theme for tenant. If theme for this tenantDNS already loaded null returned,
     * otherwise promise that will be resolved after style will be linked
     * @param tenantDNS tenantDNS
     * @param hidePageContent if true than body hides until stylesheet is loaded
     */
    api.loadTheme = function (tenantDNS, hidePageContent) {
        if (tenantDNS === currentTenantDNS) {
            return;
        }
        removeThemeStyles();
        currentTenantDNS = tenantDNS;
        return loadContent(tenantDNS, hidePageContent);
    };

    var loadContent = function (tenantDNS, hidePageContent) {
        var def = $q.defer();
        var promise = def.promise;
        if (hidePageContent) {
            hide();
        }
        setBodyStyle(true);
        loadLink(tenantDNS, def);
        return promise;
    };

    var setBodyStyle = function (add) {
        if (currentTenantDNS) {
            var styleName = "theme-" + currentTenantDNS;
            if (add) {
                $body.addClass(styleName);
            } else {
                $body.removeClass(styleName);
            }
        }
    };

    var loadLink = function (tenantDNS, deferred) {
        var path = restServiceFactory.theme.replace('{tenantDNS}', tenantDNS);
        if (frontendName) {
            path = path.replace('{frontendName}', frontendName);
        } else {
            path = path.replace('/{frontendName}', '');
        }
        $http.get(path).then(function loadCss(response) {
            if (response.data) {
                var themeFolder = response.data.split('/');
                themeFolder = themeFolder.splice(0, themeFolder.length - 2).join('/') + '/';

                var cssUrl = restServiceFactory.webResources + response.data;
                var faviconUrl = restServiceFactory.webResources + themeFolder + faviconName;

                $q.all(
                    createLinkNode({type: 'text/css', rel: 'stylesheet', href: cssUrl}),
                    createLinkNode({type: 'image/png', rel: 'icon', href: faviconUrl}, true))
                    .then(function () {
                        deferred.resolve();
                    });

            } else {
                deferred.resolve();
                show();
            }

        }, function () {
            deferred.resolve();
            show();
        });
    };

    var hide = function () {
        $body.css('display', 'none');
    };

    var show = function () {
        $body.css('display', 'block');
    };

    var createLinkNode = function (params, removeExisting) {
        var deferred = $q.defer();

        if (removeExisting) {
            var existingLink = angular.element($document[0].querySelector("link[rel*='" + params.rel + "']"));
            existingLink && existingLink.remove();
        }

        var link = angular.element('<link/>')
            .attr('type', params.type)
            .attr('rel', params.rel)
            .attr('href', params.href);

        if (link && link[0]) {
            var finallyCallback = function () {
                deferred.resolve();
                show();
            };

            link[0].onload = finallyCallback;
            link[0].onerror = finallyCallback;
        }

        removers.push(registerNode(link));

        return deferred.promise;
    };

    var registerNode = function (link) {
        $document[0].getElementsByTagName("head")[0].appendChild(link[0]);
        return function () {
            if (link && link[0]) {
                link.detach();
            }
        };
    };

    var removeThemeStyles = function () {
        removers.forEach(function (remover) {
            remover();
        });
        removers = [];
        setBodyStyle(false);
        createLinkNode({ type: 'image/png', rel: 'icon', href: './' + faviconName }, true);
    };

    /**
     * Removes linked style if it is exist.
     * Show body if {@link loadTheme} has been executed with hide flag
     */
    api.removeTheme = function () {
        removeThemeStyles();
        currentTenantDNS = null;
    };

    return api;
}