function developmentHeaderInjectorFactory($cookies) {
    var injector = {
        'request': function (config) {
            config.headers['developmentData'] = $cookies.get('developmentData');
            return config;
        }
    };

    return injector;

}