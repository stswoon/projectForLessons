## Development Header Injector - dev docs

### Goal
Add ability to enable dev mode using browser cookies (Cookie with unique name copies to every Request Header and can be used to provide custom development data from server)

### Usage
```javascript
$httpProvider.interceptors.push('developmentHeaderInjectorFactory');
```

### Implementation
This interceptor takes cookie from browser by key `developmentData` and value `true` and passes it to headers of all requests (header key = `developmentData`). So backend service can modifies its behaviour accordingly to this header.  

