## Angular Dynamization
JS function which provide ability to inject angular components, services and etc. after init angular app.

:exclamation: This approach use private angularJs api, for more info see [dev docs](/src/main/webapp/angularDynamization/docs).

### Usage

Before usage use `angularDynamization` function to add new behaviour for your app
```javascript
angular.module("app", ...).config(
    function ($controllerProvider, $provide, $compileProvider, ...) {
        angularDynamization(angular.module("app"), {
            $controllerProvider: $controllerProvider,
            $compileProvider: $compileProvider,
            $provide: $provide
        });
        ...
    }
);
```

Then you can use
```javascript
var element =  //element inside angular application
    document.getElement.getElementById(...);
var app = angular.module('app'); //already started application

element.innerHTML = "<hello-User-Component></hello-User-Component>";
app.startDynamicRegistration();
app.component('helloUserComponent', {
    template: "<div>Hello {{greeting}}</div>",
    controller: function HelloUserController($scope) {
        $scope.greeting = "John";
    }
});
app.stopDynamicRegistration(element); //element in which will
                                      //init new portion of angular
```
Also it works with factories, you can use already defined directives, factories from already started application.

By default stopDynamicRegistration use angular injector from body because it is common way
to register one angular application for whole page. But just in case you can use
```javascript
app.stopDynamicRegistration(element, injectorElement);
```

##### Dev docs
See also - [link](/src/main/webapp/angularDynamization/docs)