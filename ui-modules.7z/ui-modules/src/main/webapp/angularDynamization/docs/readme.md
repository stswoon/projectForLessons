## Angular Dynamization - dev docs
It use `ngApp._invokeQueue` (**private angular api**) to be able to init
any new angular components, factories and etc.

At the end approach based on solution - https://stackoverflow.com/a/15292441/7860797

But here was several other tries.

1. working approach - http://stackoverflow.com/questions/15250644/loading-an-angularjs-controller-dynamically
2. not checked:
 *  http://stackoverflow.com/questions/20651578/how-to-bind-an-angularjs-controller-to-dynamically-added-html
 *  http://twofuckingdevelopers.com/2013/07/creating-content-dynamically-with-angularjs/
 *  https://oricalvo.wordpress.com/2015/02/23/configuring_provider/
3. failed to use:
 *  http://stackoverflow.com/questions/22548610/can-i-use-one-ng-app-inside-another-one-in-angularjs
 *  https://www.bennadel.com/blog/2553-loading-angularjs-components-after-your-application-has-been-bootstrapped.htm