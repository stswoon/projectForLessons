## Localization

It is necessary to put the config.json and files with localized constants in the folder l10n.
* listLanguages - list of available languages. localized constants for these languages should be in the folder l10n.
* key - designation of the language.
* name - name of the language. used for localization.
* nativeName - name of the language in the native language.

Example config.json:
```shell
{
    "listLanguages": {
        "en_EN": {
            "key": "en_EN",
            "name": "EN",
            "nativeName": "English"
        },
        "ru_RU": {
            "key": "ru_RU",
            "name": "RU",
            "nativeName": "Русский"
        }
    }
}
```


### Setting app.js
Add to app.js config $translateProvider
```shell
angular.module("app", [...,'pascalprecht.translate'])
    .config(function(...,$translateProvider) {
    ...
    //Translate config
    $translateProvider.useStaticFilesLoader({
        prefix: '/l10n/',
        suffix: '.json'
    });
    $translateProvider.preferredLanguage('en_EN'); // tell the module what language to use by default
    $translateProvider.useSanitizeValueStrategy('escaped'); //security configuration
    })
...
```


### Setting gulpconfig.js
The html2js.rename should contain code:
```shell
html2js: {
        rename: function (templateUrl, templateFile) {
            ...
            if (templateUrl.indexOf("bower_components/ui-modules") >=0) {
                return templateUrl.replace("bower_components/ui-modules", "ui-modules");
            }
            ...
        }
        ...
    }
```

Add `bower_components/ui-modules/localization/**/*tmpl.html` to html.src
```shell
html: {
    src: [..., "bower_components/ui-modules/localization/**/*tmpl.html"],
    ...
    }
```

Add `bower_components/ui-modules/localization/**/*.js` to js.src
```shell
js: {
    src: [..., "bower_components/ui-modules/localization/**/*.js"],
    ...
    }
```


### Setting main.less
Add the following lines to the block:
```shell
@import "../bower_components/ui-modules/localization/button/button-localization";
@import "../bower_components/ui-modules/localization/menu/menu-localization";
```