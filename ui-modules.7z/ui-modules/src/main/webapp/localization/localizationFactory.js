function localizationFactory($rootScope, $cookies, $http, $translate, $q) {

    var factory = {};

    factory.currentLanguage = {
        "key": "en-US",
        "name": "English",
        "nativeName": "English"
    };
    factory.defaultLanguage = {
        "key": "en-US",
        "name": "English",
        "nativeName": "English"
    };

    factory.listLanguages = {};
    factory.sortListLanguages = [];
    factory.languageChangedEvent = 'languageChanged';


    factory.getResource = function(resource){
        return $translate.instant(resource);
    };

    factory.changeLanguage = function(languageKey) {
        if (factory.listLanguages[languageKey]) {

            var languageFrom = factory.currentLanguage;
            var languageTo = factory.listLanguages[languageKey];

            factory.currentLanguage = languageTo;
            $cookies.put("language", languageTo.key);
            $translate.use(languageTo.key);
            moment && moment.locale(languageTo.key);
            $http.defaults.headers.common["Accept-Language"] = languageTo.key;

            $rootScope.$emit(factory.languageChangedEvent, {from: languageFrom, to: languageTo});
        }
    };

    factory.sortLanguageList = function() {
        factory.sortListLanguages = [factory.currentLanguage];
        for (var key in factory.listLanguages) {
            if (key !== factory.currentLanguage.key) {
                factory.sortListLanguages.push(factory.listLanguages[key]);
            }
        }
    };

    factory.getSortLanguageList = function() {
        factory.sortLanguageList();
        return factory.sortListLanguages;
    };

    factory.getProperty = function(property) {
        return property && (property[factory.currentLanguage.key] || property[factory.defaultLanguage.key]) || property;
    };

    factory.getFullyTranslatedResource = function(resource) {
        var resources = {};

        for(var key in factory.listLanguages) {
            resources[key] = $translate.instant(resource, undefined, undefined, key);
        }

        return resources;
    };


    //OLD
    factory.getLanguageList = function() {
        var list = [factory.currentLanguage.key],
            key;
        for(key in factory.listLanguages) {
            if (key != factory.currentLanguage.key) list.push(key);
        }
        return list;
    };


    factory.getLanguageName = function(key) {
        return factory.listLanguages[key].name;
    };


    //Initialization
    getLocalizationConfig().then(function(){
        getLanguageFromDokerfile().then(function(){
            setupLanguageFromCookiesOrBrowserPreferences();
        }).catch(function(){
            setupLanguageFromCookiesOrBrowserPreferences();
        });
        factory.getFullyTranslatedResource("Ok");
    });

    function getLocalizationConfig(){
        var deferred = $q.defer(),
            url = 'l10n/config.json';

        $http.get(url)
            .then(function(data) {
                factory.listLanguages = data.data.listLanguages;
                deferred.resolve();
            }, function(err){
                console.log("*** localizationFactory: Get localization config error. ***", url);
                deferred.reject();
            });

        return deferred.promise;
    }

    function getLanguageFromDokerfile(){
        var deferred = $q.defer(),
            url = "./route.json";

        $http.get(url)
            .then(function (data) {
                var languageKey = data.data.localization;
                if (languageKey && factory.listLanguages[languageKey]) {
                    factory.currentLanguage = factory.listLanguages[languageKey];
                    $translate.use(languageKey);
                    moment && moment.locale(languageKey);
                    $http.defaults.headers.common["Accept-Language"] = languageKey;
                }
                deferred.resolve();
            },function (err) {
                console.log("*** localizationFactory: Can't get route.json. ***", url);
                deferred.reject();
            });

        return deferred.promise;
    }

    function setupLanguageFromCookiesOrBrowserPreferences() {
        var languageKey = $cookies.get("language");
        console.log("Get languageKey from cookies", languageKey);
        if (languageKey) {
            factory.changeLanguage(languageKey);
        } else {
            var defaultBrowserLanguage = getDefaultBrowserLanguage();
            if (defaultBrowserLanguage) {
                factory.changeLanguage(defaultBrowserLanguage);
            }
        }
    }

    function getDefaultBrowserLanguage() {
        var browserLanguage;
        if (navigator.languages) {
            navigator.languages.some(function (language) {
                browserLanguage = getAvailableLanguage(language);
                return !!browserLanguage;
            });
        } else {
            browserLanguage = getAvailableLanguage(navigator.language);
        }
        return browserLanguage;
    }

    function getAvailableLanguage(languageKey) {
        var language;
        if (factory.listLanguages[languageKey]) {
            language = factory.listLanguages[languageKey];
        } else {
            Object.keys(factory.listLanguages).some(function (availableLanguageKey) {
                if (~availableLanguageKey.indexOf(languageKey)) {
                    language = factory.listLanguages[availableLanguageKey];
                    return true;
                }
                return false;
            });
        }
        return language && language.key;
    }

    return factory;
}