function MenuLocalizationController(localizationFactory, tooltipWrapperFactory) {
    var self = this;

    self.l10n = localizationFactory;

    self.nativeName = tooltipWrapperFactory.getParams().nativeName;


    self.changeLanguage = function(language) {
        self.l10n.changeLanguage(language.key);
        tooltipWrapperFactory.close();
    }
}