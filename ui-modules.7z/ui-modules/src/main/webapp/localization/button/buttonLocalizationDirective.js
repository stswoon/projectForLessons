function buttonLocalizationDirective(localizationFactory, tooltipWrapperFactory) {
    return {
        scope: {},

        bindToController: {
            nativeName: '<'
        },

        controller: function() {
            var self = this;

            self.l10n = localizationFactory;

            self.openLanguageMenu = function(e) {
                e.stopPropagation();
                var element = angular.element(e.target);
                tooltipWrapperFactory.open("ui-modules/localization/menu/menu-localization.tmpl.html", {
                    elem: element,
                    modificator: "_language-switcher",
                    wrapperModificator: "_language-switcher",
                    nativeName: self.nativeName
                });
            };
        },

        controllerAs: "ctrl",

        templateUrl: "ui-modules/localization/button/button-localization.tmpl.html"
    };
}