module.exports = {
    //longRequest server data
    longServerActions: {},
    storeLongServerActionsResults: {},

    middleware: [
        //longRequest rest points
        {
            route: "/startLongServerAction",
            handle: function (req, res, next) {
                console.log("startLongServerAction:readRequest");

                storeLongServerActionsResults = {};
                longServerActions = {};

                var body = "";
                req.on('data', function (chunk) {
                    body += chunk;
                });
                req.on('end', function () {
                    console.log("startLongServerAction:endReadRequest:body=", body);
                    console.log("startLongServerAction:startingAction");

                    id = (new Date()).getTime();
                    actionId = "actionId-" + id;
                    resultId = "resultId-" + id;
                    storeLongServerActionsResults[resultId] = {};

                    longServerActions[actionId] = {
                        status: 'progress',
                        resultUrl: '/getResultServerLongAction?resultId=' + resultId
                    };
                    var timer = setTimeout(function () {
                        longServerActions[actionId].status = 'done';
                        storeLongServerActionsResults[resultId].result = "Server processed data: " + body;
                        console.log("Action (id=" + actionId + ") is finished");
                    }, 10 * 1000);
                    storeLongServerActionsResults[actionId] = {timer: timer}; //use actionId for terminate only just to simplify code

                    var result = {
                        progressUrl: '/checkLongServerActionProgress?actionId=' + actionId,
                        terminateUrl: "/terminateServerLongAction?actionId=" + actionId //not required
                        //also may be set resultUrl
                    };
                    res.end(JSON.stringify(result));
                    next();
                });
            }
        },
        {
            route: "/checkLongServerActionProgress",
            handle: function (req, res, next) {
                console.log("checkLongServerActionProgress:url=" + req.url);

                var actionId = req.url.split("=")[1];
                if (longServerActions[actionId].status === "done") {
                    var result = {
                        status: "done",
                        resultUrl: longServerActions[actionId].resultUrl
                    };
                    res.end(JSON.stringify(result));
                    next();
                } else if (longServerActions[actionId].status === "progress") {
                    var result = {
                        status: "progress",
                        //progress: "undefined";
                    };
                    res.end(JSON.stringify(result));
                    next();
                } else {
                    throw new Error("Unexpected error");
                }
            }
        },
        {
            route: "/getResultServerLongAction",
            handle: function (req, res, next) {
                console.log("getResultServerLongAction:url=" + req.url);

                var resultId = req.url.split("=")[1];
                if (storeLongServerActionsResults[resultId]) {
                    res.end(storeLongServerActionsResults[resultId].result);
                    next();
                } else {
                    throw new Error("Unexpected error");
                }
            }
        },
        {
            route: "/terminateServerLongAction",
            handle: function (req, res, next) {
                console.log("terminateServerLongAction:url=" + req.url);

                var actionId = req.url.split("=")[1];
                if (storeLongServerActionsResults[actionId]) {
                    clearTimeout(storeLongServerActionsResults[actionId].timer);
                    res.end("Sucess");
                    next();
                } else {
                    throw new Error("Unexpected error");
                }
            }
        },
        {
            route: "/startErrorInProgressLongServerAction",
            handle: function (req, res, next) {
                console.log("startErrorLongServerAction");

                var result = {
                    progressUrl: '/checkErrorLongServerActionProgress'
                };
                res.end(JSON.stringify(result));
                next();
            }
        },
        {
            route: "/checkErrorLongServerActionProgress",
            handle: function (req, res, next) {
                console.log("checkErrorLongServerActionProgress");
                throw new Error("Simulate server error");
            }
        },
        {
            route: "/startErrorInResultLongServerAction",
            handle: function (req, res, next) {
                console.log("startErrorInResultLongServerAction");
                var result = {
                    progressUrl: '/checkErrorInResultLongServerActionProgress'
                };
                res.end(JSON.stringify(result));
                next();
            }
        },
        {
            route: "/checkErrorInResultLongServerActionProgress",
            handle: function (req, res, next) {
                console.log("checkErrorInResultLongServerActionProgress");
                var result = {
                    status: "done",
                    resultUrl: "/getResultErrorInFinishLongServerAction"
                };
                res.end(JSON.stringify(result));
                next();
            }
        },
        {
            route: "/getResultErrorInFinishLongServerAction",
            handle: function (req, res, next) {
                console.log("getResultErrorInFinishLongServerAction");
                var err = new Error("Can't find result");
                err.status = 500;
                next(err);
            }
        },


        //moduleManager rest points
        {
            route: "/api/v1/ui-configuration/modules-provider",
            handle: function (req, res, next) {
                console.log("/api/v1/ui-configuration/modules-provider");

                var tenantDNS = req.url.split("/")[1];
                var result;
                if (tenantDNS === "Cloud") {
                    result = [
                        {
                            "name": "nc.test.helloWorld",
                            "path": "/dynamicModules/simpleModule.js",
                            "type": "dynamic"
                        },
                        {
                            "name": "nc.test.ngInNg",
                            "path": "/dynamicModules/angularModule.js",
                            "type": "dynamic"
                        },
                        {
                            "name": "nc.test.ngInNgWithService",
                            "path": "/dynamicModules/angularModule.js",
                            "type": "dynamic"
                        },
                        {
                            "name": "nc.test.loginPage",
                            "path": "/dynamicModules/angularModule.js",
                            "type": "dynamic"
                        },
                        {
                            "name": "nc.test.reactModule",
                            "path": "/dynamicModules/reactModule.js",
                            "type": "dynamic"
                        },
                        {
                            "name": "Static Module Cloud",
                            "access": true,
                            "type": "static"
                        }
                    ];
                } else if (tenantDNS === "cloud-common") {
                    result = [
                        {
                            "name": "Static Module cloud-commons",
                            "access": true,
                            "type": "static"
                        }
                    ];
                }

                setTimeout(function () {
                    res.end(JSON.stringify(result));
                    next();
                    console.log("end of /api/v1/ui-configuration/modules-provider");
                }, 5000);
            }
        },

        {
            route: "/developmentHeaderInjectorFactory",
            handle: function (req, res, next) {
                var debug = req.headers.developmentdata;
                var result = {
                    debug: debug
                };
                res.end(JSON.stringify(result));
                next();
            }
        },
        {
            route: "/api/v1/ui-configuration/theme-provider/load-theme",
            handle: function (req, res, next) {
                var urlParams = req.url.split("/");
                var tenantDNS = urlParams[1];
                var frontendName = urlParams.length == 3 ? req.url.split("/")[2] : "";
                var result;
                if (tenantDNS === "tenantWithTheme1") {
                    result = "styles/tenantWithTheme1/main.css";
                } else if (tenantDNS === "tenantWithTheme2") {
                    result = "styles/tenantWithTheme2/main.css";
                    if (frontendName) {
                        result = "styles/tenantWithTheme2/specific-fe-main.css";
                    }
                }

                setTimeout(function () {
                    res.end(result);
                    next();
                }, 2000);
            }
        }
    ]
};