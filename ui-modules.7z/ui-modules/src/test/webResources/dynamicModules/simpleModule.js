//R - wrapper for requirejs
R.define(function () {
    var exportData = {
        "nc.test.helloWorld": function (context) {
            return {
                styleSheet: "simpleModule.css",
                init: function () {
                    context.getElement().innerHTML = "<span class='red'>Hello World!</span>";

                    context.getEventBus().fire("moduleInit", {message: "Hello!"});

                    console.log("gateway from config: " + context.getConfig().gateway);

                    jQuery.get("http://www.setgetgo.com/randomword/get.php").done(function(data) {
                        alert("Random word via ajax: " + data);
                    })
                },
                destroy: function () {
                    context.getElement().innerHTML = "";
                }
            }
        }
    };
    return exportData;
});