//startDynamicRegistration and stopDynamicRegistration should be implemented by main angular application
R.define(function () {
    var exportData = {
        "nc.test.ngInNg": function (context) {
            return {
                init: function () {
                    angular.module('app').startDynamicRegistration();
                    context.getElement().innerHTML = "" +
                        "<div id='HelloUserApp'>"+
                        "<hello-User-Component></hello-User-Component>" +
                        "</div>";
                    angular.module('app')
                        .component('helloUserComponent', {
                            template:
                            "<div>" +
                            "Hello User Component </br>" +
                            "<input ng-model='name' ng-keyup='NameChange()'>" +
                            "<h1>{{greeting}}</h1>" +
                            "<h2>{{name}}</h2>" +
                            "</div>",
                            controller: function HelloUserController($scope) {
                                $scope.NameChange = function () {
                                    $scope.greeting = "Hello " + $scope.name;
                                };
                            }
                        });
                    angular.module("app").stopDynamicRegistration(context.getElement());
                },
                destroy: function () {
                    context.getElement().innerHTML = "";
                }
            }
        },

        "nc.test.ngInNgWithService": function (context) {
            return {
                init: function () {
                    angular.module('app').startDynamicRegistration();
                    context.getElement().innerHTML = "<hello-Service-Component></hello-Service-Component>";
                    angular.module('app')
                        .factory("myNgInNgWithServiceFactory", function myNgInNgWithServiceFactory(restServiceFactory) {
                            var api = {
                                gateway: function () {
                                    return restServiceFactory.ip;
                                }
                            };
                            return api;
                        })
                        .component('helloServiceComponent', {
                            template:
                            "<div>" +
                            "Hello Service</br>" +
                            "restServiceFactory.gateway = {{gateway}}</br>" +
                            "myNgInNgWithServiceFactory.gateway = {{myNgInNgWithServiceFactory.gateway()}}</br>" +
                            "</div>",
                            controller: function HelloServiceController($scope, restServiceFactory, myNgInNgWithServiceFactory) {
                                $scope.NameChange = function () {
                                    $scope.greeting = "Hello " + $scope.name;
                                };
                                $scope.gateway = restServiceFactory.ip;
                                $scope.myNgInNgWithServiceFactory = myNgInNgWithServiceFactory;
                            }
                        });
                    angular.module("app").stopDynamicRegistration(context.getElement());
                },
                destroy: function () {
                    context.getElement().innerHTML = "";
                }
            }
        },

        "nc.test.loginPage": function (context) {
            return {
                init: function () {
                    angular.module('app').startDynamicRegistration();
                    context.getElement().innerHTML = "<landing-login style='width:100px;height:100px'></landing-login>";
                    angular.module("app").stopDynamicRegistration(context.getElement());
                },
                destroy: function () {
                    context.getElement().innerHTML = "";
                }
            }
        },
    };

    return exportData;
});

