function cookiesFactory($cookies) {
    var cookiesFactory = {};

    cookiesFactory.get = function (name) {
        return $cookies.get(name);
    };

    cookiesFactory.getObject = function (name) {
        return $cookies.getObject(name);
    };

    cookiesFactory.getAll = function () {
        return $cookies.getAll();
    };

    cookiesFactory.put = function (name, value, params) {
        return $cookies.put(name, value, params);
    };

    cookiesFactory.putObject = function (name, value, params) {
        return $cookies.putObject(name, value, params);
    };

    cookiesFactory.putInObject = function (objName, propertyName, value, params) {
        var obj = $cookies.getObject(objName, params);

        if (!obj) {
            return;
        }

        obj[propertyName] = value;

        return $cookies.putObject(objName, obj, params);
    };

    cookiesFactory.remove = function (name, params) {
        return $cookies.remove(name, params);
    };

    cookiesFactory.removeInObj = function (objName, propertyName, params) {
        var obj = $cookies.getObject(objName, params);

        if (!obj) {
            return;
        }

        obj[propertyName] = null;

        return $cookies.putObject(objName, obj, params);
    };

    return cookiesFactory;
}