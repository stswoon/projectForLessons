function sessionInjectorFactory($location, SessionService, $rootScope, $q) {
    var sessionInjector = {
        request: function (config) {
            //console.log('request config', config);

            if (!SessionService.getAnonymusState()) {
                config.headers['Authorization'] = SessionService.getTokenType() + ' ' + SessionService.getAccessToken();
            }

            return config;
        },

        responseError: function (error) {
            console.log('sessionInjectorFactory response error', error);

            if (error.status === 403) {
                $rootScope.$emit('oauth:access_denied');
            }

            if (error.statusText === "Unauthorized") {
                //TODO uncomment this
                $rootScope.$emit('oauth:error', error);
            }

            return $q.reject(error);
        }
    };

    return sessionInjector;
}