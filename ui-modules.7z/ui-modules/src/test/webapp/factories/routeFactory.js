function routeFactory($http) {
    var routeFactory = {};
    routeFactory.data = false;
    routeFactory.get = function() {
        return $http.get("./route.json")
            .then(function(data) {
                //routeFactory.data = data.data;
            }, function(response) {
                console.log("*** Can't get route.json. Using mocks. ***");
                // routeFactory.data = false;
                // routeFactory.data = {
                //     "gateWay": "http://public-gateway-cloud-catalog-subscr.backup.openshift.sdntest.netcracker.com",
                //     "identityProvider": "http://identity-provider-cloud-catalog-subscr.backup.openshift.sdntest.netcracker.com"
                // }
            });
    };
    console.log("*** Can't get route.json. Using mocks. ***");
    routeFactory.data = {
        "domain": "localhost",
        "gateWay": "http://public-gateway-cloud-catalog-ui.development.openshift.sdntest.netcracker.com",
        "identityProvider": "http://public-gateway-cloud-catalog-ui.development.openshift.sdntest.netcracker.com/api/v1/identity-provider",
        "localTesting" : true
    };
    return routeFactory;
}