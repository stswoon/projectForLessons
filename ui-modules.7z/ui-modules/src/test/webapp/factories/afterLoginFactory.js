function afterLoginFactory(/*productsFactory, usersAndGroupsFactory, billingAddressesFactory*/) {
    var api = {};

    api.login = function () {
        window.alert("login sucess");
        //productsFactory.getProducts();
        //usersAndGroupsFactory.getDefaultGroup();
        //billingAddressesFactory.getBillings();
    };

    return api;
}