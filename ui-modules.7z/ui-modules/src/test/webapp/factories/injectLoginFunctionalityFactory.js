function injectLoginFunctionalityFactory() {
    var api = {};

    console.log("injectLandingLoginDirectiveFunctionalityFactory was called");

    return api;
}