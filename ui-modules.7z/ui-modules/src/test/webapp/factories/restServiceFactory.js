function restServiceFactory($http, routeFactory) {
    var routeData = routeFactory.data;

    var service = {};
    service.identity = {};
    if (routeData) {
        service.domain = routeData.domain;
        service.ip = routeData.gateWay;
        service.identity.ip = routeData.identityProvider;

        service.currentCustomer = service.ip + "/api/v1/customer-api/customers/current";
        service.setDefaultBilling = service.ip + "/api/v1/customer-api/customers/current"; //PUT

        // Products & Licenses
        service.products = service.ip + "/api/v1/customer-api/purchased-offering-instances/all";
        service.product = service.ip + "/api/v1/customer-api/purchased-offering-instances/{id}";
        service.moveProductToBilling = service.ip + "/api/v1/customer-api/customers/current/purchased-offering-instances/{id}"; //PUT
        service.moveProductsToBilling = service.ip + "/api/v1/customer-api/customers/current/purchased-offering-instances/all?billingId={id}"; //PUT
        service.productsOfBilling = service.ip + "/api/v1/customer-api/purchased-offering-instances/all?billingId={id}";

        // Users & Groups
        service.defaultGroup = service.ip + "/api/v1/customer-api/groups/root";
        service.groups = service.ip + "/api/v1/customer-api/groups/{id}/members";
        service.groupsTree = service.ip + "/api/v1/customer-api/groups/tree";

        service.createGroup = service.ip + "/api/v1/customer-api/groups";
        service.editGroup = service.ip + "/api/v1/customer-api/groups/{id}";
        service.removeGroup = service.ip + "/api/v1/customer-api/groups/{id}";
        service.createUser = service.ip + "/api/v1/customer-api/subscribers";
        service.editUser = service.ip + "/api/v1/customer-api/subscribers/{id}";
        service.removeUser = service.ip + "/api/v1/customer-api/subscribers/{id}";

        // Billings
        service.billings = service.ip + "/api/v1/customer-api/customers/billings";
        service.createBilling = service.ip + "/api/v1/customer-api/customers/billings";
        service.editBilling = service.ip + "/api/v1/customer-api/customers/billings/{id}";
        service.removeBilling = service.ip + "/api/v1/customer-api/customers/billings/{id}";

        // Assigned
        service.assignedSubscribers = service.ip + "/api/v1/customer-api/license-bundles/{id}/subscriptions";
        service.assignedProducts = service.ip + "/api/v1/customer-api/subscribers/{id}/subscriptions";

        service.assignedSubscriptions = service.ip + "/api/v1/customer-api/customers/current/subscribers/{id}/assigned-subscriptions";
        service.availableSubscriptions = service.ip + "/api/v1/customer-api/customers/current/subscribers/{id}/available-subscriptions";
        service.subscribersForLicense = service.ip + "/api/v1/customer-api/customers/current/subscriptions/{license-bundle-id}/subscribers";

        // Assign
        service.assignSubscribers = service.ip + "/api/v1/customer-api/license-bundles/{id}/assign";
        service.releaseSubscribers = service.ip + "/api/v1/customer-api/license-bundles/{id}/release";

        //TODO make proper link when cloud will be stable
        service.getTenantId = service.ip + '/api/v2/tenant-manager/registration/tenants?dns={tenantDNS}';

        // For DEV purposes
        service.createCustomer = service.ip + '/api/v1/customer-management/customers';

        // Identity Provider
        service.identity.address = service.identity.ip + '/auth/realms/{tenantId}/protocol/openid-connect/auth';
        service.identity.address_logout = service.identity.ip + "/auth/realms/{tenantId}/protocol/openid-connect/logout";
        service.identity.response_type = 'token';
        service.identity.client_id = 'frontend';

        //ui-configuration
        service.uiConfigurationModules = service.ip + "/api/v1/ui-configuration/modules-provider";
        if (routeData.localTesting) {
            service.uiConfigurationModules = "/api/v1/ui-configuration/modules-provider";
        }

        service.theme = service.ip + '/api/v1/ui-configuration/theme-provider/load-theme/{tenantDNS}/{frontendName}';
        service.webResources = service.ip + '/api/v1/ui-configuration/web-resource/';
        if (routeData.localTesting) {
            service.theme = '/api/v1/ui-configuration/theme-provider/load-theme/{tenantDNS}/{frontendName}';
            service.webResources = '';
        }
    } else {
        service.products = './mocks/products.json';
        service.users = './mocks/users.json';

        service.identity = {
            "ip": "http://wsmnn-101:18082",
            "address": "http://wsmnn-101:18082/auth/realms/{{tenantId}}/protocol/openid-connect/auth",
            "address_logout": "http://wsmnn-101:18082/auth/realms/{{tenantId}}/protocol/openid-connect/logout",
            "response_type": "token",
            "client_id": "frontend"
        };
    }

    return service;
}