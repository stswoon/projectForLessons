function SessionService(cookiesFactory) {
    var _self = cookiesFactory.getObject('sessionService');

    if (!_self) {
        _self = {};
        _self._isAnonymus = true;
    }

    this.getAnonymusState = function () {
        return _self._isAnonymus;
    };

    this.setAnonymusState = function () {
        _self._isAnonymus = true;
        cookiesFactory.putObject('sessionService', _self);
    };

    this.removeAnonymusState = function () {
        _self._isAnonymus = false;
        cookiesFactory.putObject('sessionService', _self);
    };

    this.setAccessToken = function (token) {
        _self._accessToken = token;
        cookiesFactory.putObject('sessionService', _self);
    };

    this.getAccessToken = function () {
        return _self._accessToken;
    };

    this.setTokenType = function (tokenType) {
        _self._tokenType = tokenType;
        cookiesFactory.putObject('sessionService', _self);
    };

    this.getTokenType = function () {
        return _self._tokenType;
    };

    this.clearSessionServiceInfo = function () {
        _self._isAnonymus = true;
        _self._accessToken = null;
        _self._tokenType = null;
        cookiesFactory.remove('sessionService');
    };

    this.setTenant = function(tenant) {
        _self._tenant = tenant;
        cookiesFactory.putObject('sessionService', _self);
    };

    this.getTenant = function() {
        return _self._tenant;
    };

}