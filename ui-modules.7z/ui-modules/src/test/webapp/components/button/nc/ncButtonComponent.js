function ncButtonComponent() {
    return {
        templateUrl: "src/test/webapp/components/button/nc/nc-button.tmpl.html",
        transclude: true,
        bindings: {
            color: '@',
            size: '@',
            text: '@',
            type: '@',
            mod: '@',
            customClass: '@',
            disabled: '<'
        },
        controller: function() {

            var self = this;

            this.transcludeClick = function(e) {
                if(self.disabled) {
                    e.stopPropagation();
                }
            };

        }
    }
}