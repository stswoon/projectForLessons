angular.module("app", ['HtmlTemplates', 'ui.router', 'ngCookies', 'ngAnimate', 'ngSanitize', 'emguo.poller'])
    .config(function ($stateProvider, $urlRouterProvider, $httpProvider, $controllerProvider, $provide, $compileProvider) {
        angularDynamization(angular.module("app"), {
            $controllerProvider: $controllerProvider,
            $compileProvider: $compileProvider,
            $provide: $provide
        });

        /***Need for proper XHR***/
        $httpProvider.defaults.useXDomain = false;
        $httpProvider.defaults.withCredentials = false;
        delete $httpProvider.defaults.headers.common['X-Requested-With'];

        /***oAuth***/
        $httpProvider.interceptors.push('sessionInjectorFactory');
        $httpProvider.interceptors.push('developmentHeaderInjectorFactory');

        $stateProvider
            .state('initDataState', {
                abstract: true,
                template: '<div ui-view autoscroll="true"></div>',
                resolve: { //https://blog.brunoscopelliti.com/show-route-only-after-all-promises-are-resolved/
                    route: function (routeFactory) {
                        return routeFactory.get();
                    }
                }
            })
            .state('/', {
                url: "/",
                parent: 'initDataState'
            })
            .state('404', {
                url: "/404",
                template: 'No such address',
                parent: 'initDataState'
            })
            .state('notReady', {
                url: "/notReady",
                template: 'Not ready yet',
                parent: 'initDataState'
            })
            .state('loginPage', {
                url: "/loginPage",
                controller: 'testLoginPageController',
                controllerAs: "testLoginPageCtrl",
                templateUrl: 'activities/login/testLoginPageController.tmpl.html',
                parent: 'initDataState'
            })
            .state('longRequest', {
                url: "/longRequest",
                controller: 'testLongRequestController',
                controllerAs: "testLongRequestCtrl",
                templateUrl: 'activities/longRequest/testLongRequestController.tmpl.html',
                parent: 'initDataState'
            })
            .state('moduleManager', {
                url: "/moduleManager",
                controller: 'testModuleManagerController',
                controllerAs: "testModuleManagerCtrl",
                templateUrl: 'activities/moduleManager/testModuleManagerController.tmpl.html',
                parent: 'initDataState'
            })
            .state('development', {
                url: "/development",
                controller: 'testDevelopmentController',
                controllerAs: "testDevelopmentCtrl",
                templateUrl: 'activities/development/testDevelopmentController.tmpl.html',
                parent: 'initDataState'
            })
            .state('theme', {
                url: "/theme",
                controller: 'testThemeController',
                controllerAs: "testThemeCtrl",
                templateUrl: 'activities/development/testThemeController.tmpl.html',
                parent: 'initDataState'
            })
    }).run(function ($rootScope, $location, cookiesFactory, loginFactory) {
        if (window.location.href.indexOf("logout") > -1) {
            //logout for test
            cookiesFactory.remove('globals');
            loginFactory.logout();
            document.location.href="/";
        }
    }
);
angular.module("app")
    //Test controllers
    .controller("testLoginPageController", testLoginPageController)
    .controller("testLongRequestController", testLongRequestController)
    .controller("testModuleManagerController", testModuleManagerController)
    .controller("testDevelopmentController", testDevelopmentController)
    .controller("testThemeController", testThemeController);

angular.module("app")
    .factory("afterLoginFactory", afterLoginFactory)
    .factory("cookiesFactory", cookiesFactory)
    .factory("injectLoginFunctionalityFactory", injectLoginFunctionalityFactory)
    //.factory("localizationFactory", localizationFactory)
    .factory("loginFactory", loginFactory)
    .factory("restServiceFactory", restServiceFactory)
    .factory("routeFactory", routeFactory)
    .factory("sessionInjectorFactory", sessionInjectorFactory)
    .factory("longRequestFactory", longRequestFactory)
    .factory("moduleManagerFactory", moduleManagerFactory)
    .factory("themeFactory", themeFactory)
    .factory("developmentHeaderInjectorFactory", developmentHeaderInjectorFactory);

angular.module("app")
    //.directive("buttonLocalization", buttonLocalizationDirective)
    .directive("landingLogin", landingLoginDirective);

angular.module("app")
    .service("SessionService", SessionService);

angular.module("app")
    .component("ncButton", ncButtonComponent());

angular.module("app")
    .filter("checkStaticModuleAccess", staticModuleAccessFilterFactory);
