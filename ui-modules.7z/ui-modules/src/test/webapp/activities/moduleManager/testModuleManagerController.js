function testModuleManagerController($scope, $rootScope, moduleManagerFactory, loginFactory, restServiceFactory) {
    $scope.setCloudCommonTenant = function () {
        loginFactory.getTenantId("cloud-common");
    };
    $scope.setCloudTenant = function () {
        loginFactory.getTenantId("Cloud");
    };
    $scope.clearTenant = function () {
        loginFactory.logout();
    };

    $scope.checkStaticModule = function () {
        moduleManagerFactory.isStaticModuleAccess("Static Module Cloud").then(function (flag) {
            alert(flag);
        })
    };

    $rootScope.$on('moduleManagerFactory:modulesDataChanging', function () {
        console.log("Modules data was cleared");
    });

    var remover = moduleManagerFactory.isStaticModuleAccess("Static Module Cloud", "handler", function (flag) {
        console.log("Handler for static module 'Static Module Cloud': flag=" + flag)
    });
    setTimeout(function () {
        remover.remove();
        console.log("Removed handler for static module 'Static Module Cloud'");
    }, 15 * 1000);




    moduleManagerFactory.initDynamicModuleManager({
        gateway: restServiceFactory.ip
    });
    //or for case without angular
    //var moduleManager = new ModuleManager({gateway: restServiceFactory.ip});
    //also you can make window.moduleManager = moduleManager;
    $scope.loadSimpleModule = function () {
        moduleManagerFactory.getDynamicModuleEventBus().on("moduleInit", function (event) {
            console.log(event.data.message);
        });
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder1"), "nc.test.helloWorld");
    };
    $scope.destroySimpleModule = function () {
        moduleManagerFactory.destroyDynamicModule(document.getElementById("placeholder1"));
    };
    $scope.loadSimpleModuleInAnotherDiv = function () {
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder1_2"), "nc.test.helloWorld");
    };
    $scope.destroySimpleModuleInAnotherDiv = function () {
        moduleManagerFactory.destroyDynamicModule(document.getElementById("placeholder1_2"));
    };
    $scope.loadNotExistedModule = function () {
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder1_3"), "nc.test.notExist");
    };
    $scope.loadAngularModule = function () {
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder2"), "nc.test.ngInNg");
    };
    $scope.loadAngularWithServiceModule = function () {
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder3"), "nc.test.ngInNgWithService");
    };
    $scope.loadAngularLoginModule = function () {
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder4"), "nc.test.loginPage");
    };
    $scope.loadReactModule = function () {
        moduleManagerFactory.initDynamicModule(document.getElementById("placeholder5"), "nc.test.reactModule");
    };
    $scope.destroyAllDynamics = function () {
        moduleManagerFactory.destroyAllDynamicModules();
    };
}