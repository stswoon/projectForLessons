function testLongRequestController($scope, longRequestFactory) {
    var _longRequest = null;

    $scope.startLongRequest = function () {
        $scope.status = "in progress, see console";
        var longRequest = longRequestFactory.create();
        longRequest.init({
            method: 'POST',
            url: "/startLongServerAction",
            data: {message: "Test data from client", version: 1},
            resultHeaders: {Accept: "text/plain"}
        });
        _longRequest = longRequest;
        longRequest.send().then(function (response) {
            $scope.status = "success";
            console.log("showing alert");
            window.alert(response.data);
        }, function (response) {
            $scope.status = "fail";
            console.log("Failed to finish long request. Cause is ", response.data);
        });
    };

    $scope.terminateLongRequest = function () {
        $scope.status = "in progress, see console";
        _longRequest.terminate().then(function (response) {
            console.log("terminated client and server");
            $scope.status = "success";
        }, function (response) {
            console.log("terminated only client");
            $scope.status = "success but only client";
        });
    };

    $scope.sendSameLongRequestAfterFinishFirst = function () {
        $scope.status = "in progress, see console";
        _longRequest.send().then(function (response) {
            $scope.status = "success";
            console.log("second call, see network", response);
        });
    };

    $scope.startLongRequestWithNotExistUrl = function () {
        $scope.status = "in progress, see console";
        var longRequest = longRequestFactory.create();
        longRequest.init("/notExistUrl");
        longRequest.send().then(function (response) {
            $scope.status = "success";
            console.log("startLongRequestWithNotExistUrl:success:response=",response);
        }, function (response) {
            $scope.status = "fail";
            console.log("Failed to finish long request. Cause is ", response.data);
        })
    };

    $scope.startLongRequestWithErrorInProgress = function () {
        $scope.status = "in progress, see console";
        var longRequest = longRequestFactory.create();
        longRequest.init("/startErrorInProgressLongServerAction");
        longRequest.send().then(function (response) {
            $scope.status = "success";
            console.log("startLongRequestWithNotExistUrl:success:response=",response);
        }, function (response) {
            $scope.status = "fail";
            console.log("Failed to finish long request. Cause is ", response.data);
        })
    };

    $scope.startLongRequestWithErrorInResult = function () {
        $scope.status = "in progress, see console";
        var longRequest = longRequestFactory.create();
        longRequest.init("/startErrorInResultLongServerAction");
        longRequest.send().then(function (response) {
            $scope.status = "success";
            console.log("startLongRequestWithNotExistUrl:success:response=",response);
        }, function (response) {
            $scope.status = "fail";
            console.log("Failed to finish long request. Cause is ", response.data);
        })
    };

    $scope.startLongRequestWithUrlPrefix = function () {
        $scope.status = "in progress, see console";
        var longRequest = longRequestFactory.create();
        longRequest.init({
            method: 'POST',
            url: "/startLongServerAction",
            urlPrefix: "fakePrefix"
        });
        _longRequest = longRequest;
        longRequest.send().then(function (response) {
            $scope.status = "success";
            console.log("success");
        }, function (response) {
            $scope.status = "fail";
            console.log("Failed to finish long request. Cause is ", response.data);
        });
    };
}