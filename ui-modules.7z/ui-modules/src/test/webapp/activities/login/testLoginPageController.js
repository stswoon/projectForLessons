function testLoginPageController($rootScope, loginFactory) {
    $rootScope.$on('loginFactory:login', function (event, data) {
        console.log("Event 'loginFactory:login': data=", data, ", event=", event);
    });

    $rootScope.$on('loginFactory:logout', function (event, data) {
        console.log("Event 'loginFactory:logout': data=", data, ", event=", event);
    });

    var handlerRegistration = loginFactory.onTenantDNSChange(function (data) {
        console.log("TenantDNS changed: data=", data);
    });

    loginFactory.addTenantToUserLoginMiddleware(function (next) {
        setTimeout(function () {
            console.log("Async TenantDNSChange - 1");
            console.log("loginFactory.getTenantDNS = " + loginFactory.getTenantDNS());
            next();
        }, 5000);
    });
    loginFactory.addTenantToUserLoginMiddleware(function (next) {
        console.log("Async TenantDNSChange - 2");
        next();
    });

    setTimeout(function () {
        console.log("remove onTenantDNSChange handler");
        handlerRegistration.remove();
    }, 15 * 1000);

}