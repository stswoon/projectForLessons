function testThemeController($scope, themeFactory) {
    $scope.frontendName = null;
    $scope.tenant = null;
    $scope.hide = true;

    $scope.changeTheme = function () {
        var tenant = $scope.tenant;
        var frontendName = $scope.frontendName;
        if (frontendName) {
            themeFactory.setFrontendName("testFE");
        } else {
            themeFactory.setFrontendName("");
        }
        themeFactory.loadTheme(tenant, $scope.hide);
    };

    $scope.removeTheme = function () {
        themeFactory.removeTheme();
    };
}