"use strict";

const config = require('./gulpconfig');

let gulp = require('gulp');
let plugins = require('gulp-load-plugins')(config.plugins);
let exec = require('child_process').exec;
let browserSync = require('browser-sync');
let del = require("del");
let wrapTemplate = '(function() {\n<%= contents %>\n})();';
var bower = require('gulp-bower');
var runSequence = require('run-sequence');
let gulpReplace = require('gulp-replace');
let fs = require('file-system');

gulp.task("download-deps", () => bower());

gulp.task("clean-target", () =>
    del(config.cleanPaths.target, {
        force: true
    }).then(paths => {
        console.log('Deleted files and folders:\n', paths.join('\n'));
    })
);

gulp.task('build', ["build1", "build2", "build3", "build4", "buildModuleManager", "angularDynamization", "buildDebugInjector", "buildTheme"]);

gulp.task('publish', () =>
    runSequence("clean-depsNtarget", "download-deps", "build", () =>
        console.warn("To be done (as WA publish as git branch dist manually)")  //todo:publish in bower\npm
    )
);

gulp.task("clean-depsNtarget", ["clean-target"], () =>
    del(config.cleanPaths.deps, {
        force: true
    }).then(paths => {
        console.log('Deleted files and folders:\n', paths.join('\n'));
    })
);

gulp.task("clean-all", ["clean-depsNtarget"], () =>
    del(config.cleanPaths.nodes, {
        force: true
    }).then(paths => {
        console.log('Deleted files and folders:\n', paths.join('\n'));
    })
);

gulp.task('test-server', () =>
    runSequence("clean-target", 'build-test', "watch", "browserSyncWatch")
);


//---------- private tasks

gulp.task('---private task separator---');

gulp.task('build1', () =>
    gulp.src(config.build.src1)
        .pipe(gulp.dest(config.build.dest1))
);
gulp.task('build2', () =>
    gulp.src(config.build.src2)
        .pipe(gulp.dest(config.build.dest2))
);
gulp.task('build3', () =>
    gulp.src(config.build.src3)
        .pipe(gulp.dest(config.build.dest3))
);
gulp.task('build4', () =>
    gulp.src(config.build.src4)
        .pipe(gulp.dest(config.build.dest4))
);
gulp.task('buildModuleManager', ["buildModuleManager-source", "buildModuleManager-requireWrap", "buildModuleManager-moduleManager"]);
gulp.task('buildModuleManager-source', () =>
    gulp.src(config.build.src5)
        .pipe(gulp.dest(config.build.dest5))
);
gulp.task('buildModuleManager-requireWrap', () => {
    var fileContent = fs.readFileSync("bower_components/requirejs/require.js", "utf8");
    return gulp.src("src/main/webapp/moduleManager/distinct/utils/requireWrap.js")
        .pipe(gulpReplace("//###insertRequireJS###", fileContent))
        // .pipe(plugins.uglify())
        .pipe(gulp.dest(config.build.dest6))
});
gulp.task('buildModuleManager-moduleManager', () =>
    gulp.src(config.build.src7)
        .pipe(plugins.concat(config.build.outputFile7))
        .pipe(plugins.wrap(config.build.wrapTemplate7))
        .pipe(gulp.dest(config.build.dest7))
);
gulp.task('angularDynamization', () =>
    gulp.src(config.build.src8)
        .pipe(gulp.dest(config.build.dest8))
);
gulp.task('buildDebugInjector', () =>
    gulp.src(config.build.src10)
        .pipe(gulp.dest(config.build.dest10))
);
gulp.task('buildTheme', () =>
    gulp.src(config.build.src9)
        .pipe(gulp.dest(config.build.dest9))
);


gulp.task('build-test', (callback) =>
    runSequence("build", "less:prod", "js:prod", "copy", "htmlRevisionInject", callback)
);

/*Less tasks*/
gulp.task('less:prod', () =>
    gulp.src(config.less.src)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(plugins.sourcemaps.init(config.sourceMapsOptions))
        .pipe(plugins.less())
        .pipe(plugins.autoprefixer(config.autoprefixer))
        .pipe(plugins.minifyCSS())
        .pipe(plugins.rev())//comment
        .pipe(plugins.sourcemaps.write())
        .pipe(gulp.dest(config.less.dest))
        .pipe(plugins.rev.manifest(config.manifest.files, {
            base: config.manifest.dest,
            merge: true // merge with the existing manifest (if one exists)
        }))
        .pipe(gulp.dest(config.less.dest))
);

//JS tasks
gulp.task('js:prod', ['html2js:prod'], () =>
    gulp.src(config.js.src)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(plugins.sourcemaps.init(config.sourceMapsOptions))
        .pipe(plugins.concat(config.js.outputFileName))
        .pipe(plugins.ngannotate())

        .pipe(plugins.wrap(wrapTemplate))
        //.pipe(plugins.uglify({mangle: false,  sourceMapIncludeSources: true, compress: {join_vars: false, sequences: false}}))//comment

        .pipe(plugins.sourcemaps.write())
        .pipe(plugins.rev())//comment
        .pipe(gulp.dest(config.js.dest))
        .pipe(plugins.rev.manifest(config.manifest.files, {
            base: config.manifest.dest,
            merge: true // merge with the existing manifest (if one exists)
        }))
        .pipe(gulp.dest(config.js.dest))
);

/*HTML tasks*/
gulp.task('html2js:prod', () =>
    gulp.src(config.html.src, {base: './'})
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        // .pipe(plugins.minifyHtml({//comment
        //      empty: true,
        //      spare: true,
        //      quotes: true
        //  }))
        .pipe(plugins.html2js({
            moduleName: "HtmlTemplates",
            rename: config.html2js.rename
        }))
        .pipe(plugins.concat(config.html.templateName))
        //.pipe(plugins.uglify())//comment
        .pipe(gulp.dest(config.html.dest))
);

gulp.task('htmlRevisionInject', function () {
    return gulp.src(config.manifest.src)
        .pipe(plugins.plumber({
            errorHandler: onPlumberError
        }))
        .pipe(plugins.revreplace({manifest: gulp.src(config.manifest.files)}))
        .pipe(gulp.dest(config.manifest.dest));
});


//copy in prod task
gulp.task('copy', ["copy1", "copy2", "copy3", "copy4", "copy5"]);
gulp.task('copy1', function () {
    return gulp.src(config.copy.src1)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest1));
});
gulp.task('copy2', function () {
    return gulp.src(config.copy.src2)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest2));
});
gulp.task('copy3', function () {
    return gulp.src(config.copy.src3)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest3));
});
gulp.task('copy4', function () {
    return gulp.src(config.copy.src4)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest4));
});
gulp.task('copy5', function () {
    return gulp.src(config.copy.src5)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest5));
});

//Watchers
gulp.task('watch', function () {
    gulp.watch(config.watch.src, ["build-test"]);
});

gulp.task('browserSyncWatch', ['browserSync'], function () {
    gulp.watch(config.watch.target).on('change', browserSync.reload);
});

//Browser sync
const testServerConfig = require('./src/test/server/mockServer');
gulp.task('browserSync', function () {
    browserSync.init({
        server: {
            baseDir: "./target/test"
        },
        middleware: testServerConfig.middleware //https://www.browsersync.io/docs/options#option-middleware
    });
});

//---------- helpers

process.on('uncaughtException', function (err) {
    console.error(err.message, err.stack, err.errors);
    process.exit(255);
});

gulp.on('err', function (gulpErr) {
    if (gulpErr.err) {
        console.error("Gulp error details", [gulpErr.err.message, gulpErr.err.stack, gulpErr.err.errors].filter(Boolean));
    }
});

function onPlumberError(error) {
    console.log(error);
    this.emit('end');
}