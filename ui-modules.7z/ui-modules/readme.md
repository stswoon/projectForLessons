Start 'build-deps' npm task (e.g. right click in idea on package.json, click show tasks in the bottom of menu,
click on the task).

Then you should use gulp task (e.g. same way by clicking on Gulpfile.js):
1. download-deps
2. test-server

Publishing is manual:
1. 'build'
2. copy files from 'target/dist' to branch 'dist'
3. commit it

In other component use 'bower cache clean' and dependency like:
* "ui-modules" : "https://git.netcracker.com/nekhozhin/ui-modules/repository/archive.tar.gz?ref=dist"

List of functionality:
1. [Login Page](/src/main/webapp/login)
2. Localization
3. [Long Request](/src/main/webapp/longRequest)
4. [Angular Dynamization](/src/main/webapp/angularDynamization)