module.exports = {
    html2js: {
        rename: function (templateUrl, templateFile) {
            //test entities
            if (templateUrl.indexOf("activities/login/testLoginPageController.tmpl.html") > 0) {
                return "activities/login/testLoginPageController.tmpl.html";
            }
            if (templateUrl.indexOf("activities/longRequest/testLongRequestController.tmpl.html") > 0) {
                return "activities/longRequest/testLongRequestController.tmpl.html";
            }
            if (templateUrl.indexOf("activities/moduleManager/testModuleManagerController.tmpl.html") > 0) {
                return "activities/moduleManager/testModuleManagerController.tmpl.html";
            }
            if (templateUrl.indexOf("activities/development/testDevelopmentController.tmpl.html") > 0) {
                return "activities/development/testDevelopmentController.tmpl.html";
            }
            if (templateUrl.indexOf("activities/theme/testThemeController.tmpl.html") > 0) {
                return "activities/development/testThemeController.tmpl.html";
            }

            //source entities
            if (templateUrl === "target/dist/login/source/landing-login.tmpl.html") {
                return "ui-modules/login/source/landing-login.tmpl.html";
            }

            return templateUrl;
        }
    },
    sourceMapsOptions: {
        loadMaps: true,
        identityMap: true,
        largeFile: true
    },
    manifest: {
        dest: 'target/test/',
        src: "target/test/index.html",
        files: "target/test/rev-manifest.json"
    },
    cleanPaths: {
        nodes: ['./node_modules'],
        deps: ['./bower_components'],
        target: ['./target']
    },
    html: {
        src: [
            'src/test/webapp/**/*.tmpl.html',
            'target/dist/login/source/**/*.tmpl.html'
        ],
        srcProd: ['target/test/main.js', 'target/test/ngTemplates.js'],
        prodFileName: 'main.js',
        dest: 'target/test/',
        templateName: 'ngTemplates.js'
    },
    autoprefixer: {
        browsers: [
            'last 2 versions',
            'safari 5',
            'ie 9',
            'opera 12.1',
            'ios 6',
            'android 4'
        ],
        cascade: true
    },
    build: {
        src1: ['src/main/webapp/login/**', '!src/main/webapp/login/distinct/**', '!src/main/webapp/login/distinct/'],
        dest1: 'target/dist/login/source',
        src2: ["src/main/webapp/login/distinct/**"],
        dest2: 'target/dist/login/distinct',
        src3: ["src/main/webapp/localization/**"],
        dest3: 'target/dist/localization',
        src4: ["src/main/webapp/longRequest/**"],
        dest4: 'target/dist/longRequest',
        src5: ["src/main/webapp/moduleManager/**", '!src/main/webapp/moduleManager/distinct/**', '!src/main/webapp/moduleManager/distinct/'],
        dest5: 'target/dist/moduleManager/source',
        //src6: ["src/main/webapp/moduleManager/distinct/**"],
        dest6: 'target/dist/moduleManager/distinct',
        src7: [
            "src/main/webapp/moduleManager/distinct/eventBus.js",
            "src/main/webapp/moduleManager/distinct/moduleManager.js"
        ],
        outputFile7: 'moduleManager.js',
        wrapTemplate7: '(function() {\n<%= contents %>\n return window.ModuleManager = publicApi.ModuleManager; \n}());',
        dest7: 'target/dist/moduleManager/distinct/',
        src8: ["src/main/webapp/angularDynamization/**"],
        dest8: 'target/dist/angularDynamization',
        src9: ["src/main/webapp/theme/**"],
        dest9: 'target/dist/theme',
        src10: ["src/main/webapp/development/**"],
        dest10: 'target/dist/development',
    },
    less: {
        srcProd: "target/test/main.css",
        src: 'src/test/webapp/styles/main.less',
        dest: 'target/test/'
    },
    js: {
        srcProd: "target/test/main.js",
        outputFileName: "main.js",
        src: [
            "bower_components/underscore/underscore-min.js",
            "bower_components/jquery/dist/jquery.min.js",
            "bower_components/velocity/velocity.min.js",
            //"bower_components/angular/angular.min.js",
            "bower_components/angular/angular.js",
            "bower_components/angular-cookies/angular-cookies.min.js",
            "bower_components/angular-animate/angular-animate.min.js",
            "bower_components/angular-sanitize/angular-sanitize.min.js",
            "bower_components/angular-ui-router/release/angular-ui-router.min.js",
            "bower_components/angular-poller/angular-poller.min.js",
            "bower_components/es6-promise/es6-promise.min.js",
            "target/dist/angularDynamization/**/*.js",
            "target/dist/login/source/**/*.js",
            "target/dist/longRequest/**/*.js",
            "target/dist/moduleManager/distinct/requireWrap.js",
            "target/dist/moduleManager/distinct/moduleManager.js",
            "target/dist/moduleManager/source/**/*.js",
            "target/dist/development/**/*.js",
            "target/dist/theme/**/*.js",
            "src/test/webapp/**/*.js",
            "target/test/ngTemplates.js"
        ],
        dest: 'target/test/'
    },
    watch: {
        src: ["src/**/*"],
        target: ["target/**/*"]
    },
    copy: {
        src1: ["src/test/webapp/index.html", "src/test/webapp/route.json"],
        dest1: "target/test/",
        src2: ["target/dist/login/distinct/**"],
        dest2: "target/test/",
        src3: ["src/test/webapp/fonts/**"],
        dest3: "target/test/fonts",
        src4: ["target/dist/moduleManager/distinct/**"],
        dest4: "target/test/moduleManager",
        src5: ["src/test/webResources/**"],
        dest5: "target/test"
    },
    plugins: {
        scope: ['dependencies', 'devDependencies', 'peerDependencies'],
        rename: {
            'gulp-ng-annotate': 'ngannotate',
            'gulp-sourcemaps': 'sourcemaps',
            'gulp-plumber': 'plumber',
            'gulp-less': 'less',
            'gulp-autoprefixer': 'autoprefixer',
            'gulp-cssnano': 'minifyCSS',
            'gulp-image-data-uri': 'uri',
            'gulp-concat': 'concat',
            'gulp-uglify': 'uglify',
            'gulp-copy': 'copy',
            'gulp-rev': 'rev',
            'gulp-rev-replace': 'revreplace',
            'gulp-imagemin': 'imagemin',
            'gulp-ng-html2js': 'html2js',
            'gulp-minify-html': 'minifyHtml',
            'gulp-wrap': 'wrap',
            'gulp-war': 'war',
            'gulp-zip': 'zip'
        }
    }
};