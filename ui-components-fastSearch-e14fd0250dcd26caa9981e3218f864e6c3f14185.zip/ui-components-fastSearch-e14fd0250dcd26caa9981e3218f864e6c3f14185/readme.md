# UIComponents
This repo is for distribution on `nc.npm`. The source for this module is in the
[UIComponents repo](https://git.netcracker.com/DEMO.Platform.Saas_Cloud_Catalog/ui-components).
Please file issues and pull requests against that repo.

## Install
You can install this package either with `nc.npm`.
```shell
npm install ui-components
```
or `bower` via [WA](https://bass.netcracker.com/display/UX/NPM+usage#NPMusage-Использованиеbowerдлязависимостей)

## Documentation
Collection of ui-components for cloud apps developed with angular 1.x
There are simple components:
* Base Styles (in progress)
* Input (not started)
* Button (not started)
* [Fast Search](src/main/webapp/fastSearch) (in progress)

And complex components:
* Form (not started)
* Table (not started)
* Tree (not started)

###Usage
In your project you should:
1) Install ui-components as dependency (for now lets think that you use bower);
2) Add less\js from bower_components/ui-components to your build scope. If you use gulp file like we: 
```js
//gulpconfig.js
...
js: {
    outputFileName: "main.js",
    src: [
        ...
        "bower_components/ui-components/fastSearch/**.js",
        ...
    ]
}
...
html: {
    src: [
        ...
        'bower_components/ui-components/fastSearch/**.tmpl.html',
        ...
    ],
    prodFileName: 'main.js',
    templateName: 'ngTemplates.js'    
}
...
html2js: {
    rename: function (templateUrl, templateFile) {
        ...
        if (templateUrl.indexOf("fastSearch/fastSearch.tmpl.html") > 0) {  //todo auto-alias
            return "ui-components/fastSearch/fastSearch.tmpl.html";
        }
        ...
        return templateUrl;
    }
}
```
3) Add components to you angular app. Example:  
```js
angular.module("app").component("fastSearch", fastSearchComponent());
```
4) Use component inside your controller. Example:  
```html
<div ng-controller="testFastSearchController">
    <fast-search search-callback="doSearch(value);"></fast-search>
</div>
```

## Developer docs
Inner developer [docs](docs)

## License
NetCracker
