"use strict";

const config = require('./gulpconfig');

let gulp = require('gulp');
let plugins = require('gulp-load-plugins')(config.plugins);
let browserSync = require('browser-sync');
let del = require("del");
let wrapTemplate = '(function() {\n<%= contents %>\n})();';
let bower = require('gulp-bower');
let runSequence = require('run-sequence');
var npm = require('npm');
var fs = require('fs');

gulp.task("clean", ["clean-target"]);

gulp.task("clean-depsNtarget", ["clean-target", "clean-deps"]);

gulp.task("install", ["download-bower-deps"]);

gulp.task('build', ["buildJson", "buildAll", "buildBaseStyles", "buildBaseStylesDistinct"]);

gulp.task('publish', () =>
    runSequence("clean-depsNtarget", "install", "build", "npm-publish")
);

gulp.task('run-test-server', () =>
    runSequence("clean-target", "serve")
);



//---------- private tasks
gulp.task('---private task separator---');


//clean tasks
gulp.task("clean-target", () =>
    del(config.cleanPaths.target, {
        force: true
    }).then(paths => {
        console.log('Deleted files and folders:\n', paths.join('\n'));
    })
);
gulp.task("clean-deps", () =>
    del(config.cleanPaths.deps, {
        force: true
    }).then(paths => {
        console.log('Deleted files and folders:\n', paths.join('\n'));
    })
);
gulp.task("clean-all", ["clean-depsNtarget"], () =>
    del(config.cleanPaths.nodes, {
        force: true
    }).then(paths => {
        console.log('Deleted files and folders:\n', paths.join('\n'));
    })
);


//download deps task
gulp.task("download-bower-deps", () => bower());



//publish task
/**
 * Created based on http://blog.entelect.co.za/automatically-publish-to-npm-using-gulp-teamcity and
 * https://bass.netcracker.com/display/UX/NPM+usage#NPMusage-Публикация
 *
 * There were a lot of pain, options like: gulp-run, child_process, window bat file, gulp-shell, npm-cli-login
 * didn't work. Some of them cant call npm. Some of them can't work with user input for credentials, also npm
 * didn't provide ability to transfer login\password as keys for npm login command. There is a way to store in
 * .npmrc file but I failed to make it works per project. Seems same problems was forced to one gay to write
 * automatically-publish-to-npm-using-gulp-teamcity paper. So here it is with some additions.
 */
gulp.task('npm-publish', function (callback) {
    var uri = "https://nexusnpmcn.netcracker.com/repository/nc.npm.dev/";
    var username = "x_local_nc.npm.dev"; //argv.username;
    var password = "nc.npm.devPASS"; //argv.password;
    var email = "x_local_nc.npm.dev@netcracker.com"; //argv.email;
    if (!username) {
        var usernameError = new Error("Username is required as an argument --username exampleUsername");
        return callback(usernameError);
    }
    if (!password) {
        var passwordError = new Error("Password is required as an argument --password  examplepassword");
        return callback(passwordError);
    }
    if (!email) {
        var emailError = new Error("Email is required as an argument --email example@email.com");
        return callback(emailError);
    }

    npm.load(null, function (loadError) {
        if (loadError) {
            return callback(loadError);
        }
        var auth = {
            username: username,
            password: password,
            email: email,
            alwaysAuth: true
        };
        var addUserParams = {
            auth: auth
        };
        //adduser and login are the same command
        npm.registry.adduser(uri, addUserParams, function (addUserError, data, raw, res) {
            if (addUserError) {
                return callback(addUserError);
            }

            var metadata = require('./target/dist/package.json');
            metadata = JSON.parse(JSON.stringify(metadata));
            npm.commands.pack(["./target/dist"], function (packError) {
                if (packError) {
                    logout(addUserParams, data.token);
                    return callback(packError);
                }

                var fileName = metadata.name + '-' + metadata.version + '.tgz';
                var bodyPath = require.resolve('./' + fileName);
                var body = fs.createReadStream(bodyPath);
                var publishParams = {
                    metadata: metadata,
                    access: 'public',
                    body: body,
                    auth: auth
                };
                npm.registry.publish(uri, publishParams, function (publishError, resp) {
                    if (publishError) {
                        deleteArchive(fileName);
                        logout(addUserParams, data.token);
                        return callback(publishError);
                    }
                    console.log("Publish succesfull: " + JSON.stringify(resp));

                    deleteArchive(fileName);
                    logout(addUserParams, data.token, callback);
                });
            })
        });
    });

    function logout(addUserParams, token, callback) {
        addUserParams.auth.token = token;
        npm.registry.logout(uri, addUserParams, function (logoutError, data, raw, res) {
            if (callback) {
                if (logoutError) {
                    return callback(logoutError);
                }
                return callback();
            }
        });
    }

    function deleteArchive(filePath) {
        del(filePath, {
            force: true
        }).then(paths => {
            console.log('Deleted files and folders:\n', paths.join('\n'));
        });
    }

});



//build code for production
gulp.task('buildJson', () =>
    gulp.src(config.build.srcJson)
        .pipe(gulp.dest(config.build.destAll))
);
gulp.task('buildAll', () =>
    gulp.src(config.build.srcAll)
        .pipe(gulp.dest(config.build.destAll))
);
gulp.task('buildBaseStyles', () =>
    gulp.src(config.build.srcBaseStyles)
        .pipe(gulp.dest(config.build.destBaseStyles))
);
gulp.task('buildBaseStylesDistinct', () =>
    gulp.src(config.build.srcBaseStylesDistinct)
        .pipe(gulp.dest(config.build.destBaseStylesDistinct))
);



//build test environment
gulp.task('build-test', (callback) =>
    runSequence('build', "less", "js", "copy", "htmlRevisionInject", callback)
);
gulp.task('less', () =>
    gulp.src(config.less.src)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(plugins.sourcemaps.init(config.sourceMapsOptions))
        .pipe(plugins.less())
        .pipe(plugins.autoprefixer(config.autoprefixer))
        .pipe(plugins.minifyCSS())
        .pipe(plugins.rev())
        .pipe(plugins.sourcemaps.write())
        .pipe(gulp.dest(config.less.dest))
        .pipe(plugins.rev.manifest(config.manifest.files, {
            base: config.manifest.dest,
            merge: true // merge with the existing manifest (if one exists)
        }))
        .pipe(gulp.dest(config.less.dest))
);
gulp.task('js', ['html2js'], () =>
    gulp.src(config.js.src)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(plugins.sourcemaps.init(config.sourceMapsOptions))
        .pipe(plugins.concat(config.js.outputFileName))
        .pipe(plugins.ngannotate())

        .pipe(plugins.wrap(wrapTemplate))
        //.pipe(plugins.uglify({mangle: false,  sourceMapIncludeSources: true, compress: {join_vars: false, sequences: false}}))//comment

        .pipe(plugins.sourcemaps.write())
        .pipe(plugins.rev())//comment
        .pipe(gulp.dest(config.js.dest))
        .pipe(plugins.rev.manifest(config.manifest.files, {
            base: config.manifest.dest,
            merge: true // merge with the existing manifest (if one exists)
        }))
        .pipe(gulp.dest(config.js.dest))
);
gulp.task('html2js', () =>
    gulp.src(config.html.src, {base: './'})
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        // .pipe(plugins.minifyHtml({//comment
        //      empty: true,
        //      spare: true,
        //      quotes: true
        //  }))
        .pipe(plugins.html2js({
            moduleName: "HtmlTemplates",
            rename: config.html2js.rename
        }))
        .pipe(plugins.concat(config.html.templateName))
        //.pipe(plugins.uglify())//comment
        .pipe(gulp.dest(config.html.dest))
);
gulp.task('htmlRevisionInject', function () {
    return gulp.src(config.manifest.src)
        .pipe(plugins.plumber({
            errorHandler: onPlumberError
        }))
        .pipe(plugins.revreplace({manifest: gulp.src(config.manifest.files)}))
        .pipe(gulp.dest(config.manifest.dest));
});


//--- copy in prod tasks
gulp.task('copy', ["copyIndex", "copyBaseStylesDistinct"]);
gulp.task('copyIndex', function () {
    return gulp.src(config.copy.srcIndex)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest));
});
gulp.task('copyBaseStylesDistinct', function () {
    return gulp.src(config.copy.srcBaseStylesDistinct)
        .pipe(plugins.plumber({errorHandler: onPlumberError}))
        .pipe(gulp.dest(config.copy.dest));
});


//--- browser sync

//See right configuration https://www.browsersync.io/docs/gulp
//Tasks designed in such way to build test environment only after change sources and
//after build reload browser only once. In case of changing files in target you nee to rebuild
//or reload browser by yourself (if we tries to watch target than browser will be reload several
//times and such behaviour is not appropriate for the majority cases). Also there is no any
//watch about node_modules ar bower_components because it's waste of time to listen them.

// a task that ensures the `build-test` task is complete before reloading browsers
gulp.task('buildAndReload', ['build-test'], function (done) {
    browserSync.reload();
    done();
});
// default task to launch BrowserSync and watch files
gulp.task('serve', ['build-test'], function () {
    browserSync.init({
        server: {
            baseDir: "./target/test"
        }
    });
    // add browserSync.reload to the tasks array to make
    // all browsers reload after tasks are complete.
    gulp.watch(config.watch.src, ['buildAndReload']);
});




//---------- helpers

process.on('uncaughtException', function (err) {
    console.error(err.message, err.stack, err.errors);
    process.exit(255);
});

gulp.on('err', function (gulpErr) {
    if (gulpErr.err) {
        console.error("Gulp error details", [gulpErr.err.message, gulpErr.err.stack, gulpErr.err.errors].filter(Boolean));
    }
});

function onPlumberError(error) {
    console.log(error);
    this.emit('end');
}