# Developer documentation
This folder contains pictures and docs, schemes for developers.  

## Run application
```shell
npm i
gulp install
gulp run-test-server
```

## //todo
* Gulp structure 
* project structure 
* Npm publish
* docs structure
* common structure


