// Karma configuration 
// Generated on Thu Feb 11 2016 12:02:59 GMT+0300 (Russia TZ 2 Standard Time)

module.exports = function (config) {
    config.set({
        // base path that will be used to resolve all patterns (eg. files, exclude)
        basePath: '',

        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['jasmine'],

        // list of files / patterns to load in the browser
        files: [
            "bower_components/underscore/underscore-min.js",
            "bower_components/jquery/dist/jquery.min.js",
            "bower_components/angular/angular.min.js",
            "bower_components/angular-cookies/angular-cookies.min.js",
            "bower_components/angular-animate/angular-animate.min.js",
            "bower_components/angular-sanitize/angular-sanitize.min.js",
            "bower_components/angular-ui-router/release/angular-ui-router.min.js",
            'bower_components/angular-mocks/angular-mocks.js',
            'bower_components/karma-read-json/karma-read-json.js',
            'scripts/dev/**/!(app).js',
            'scripts/dev/app.js',
            'test/**/*Spec.js',
            {pattern: 'mocks/**/*.json', included: false}
        ],

        preprocessors: {
            // add webpack as preprocessor
            'test/**/*Spec.js': ['webpack']
        },

        webpack: {
            // karma watches the test entry points
            // (you don't need to specify the entry option)
            // webpack watches dependencies

            // webpack configuration
            module: {
                loaders: [
                    {
                        test: /\.js$/,
                        loader: "babel",
                        query: {
                            cacheDirectory: true,
                            presets: ['es2015']
                        }
                    }
                ]
            }
        },

        webpackMiddleware: {
            // webpack-dev-middleware configuration
            // i. e.
            noInfo: true
        },

        // list of files to exclude
        exclude: [],

        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        // preprocessors: {
        //     'scripts/dev/**/*.js': ['coverage']
        // },

        // test results reporter to use
        // possible values: 'dots', 'progress'
        // available reporters: https://npmjs.org/browse/keyword/karma-reporter
        //reporters: ['progress', 'coverage'],
        reporters: ['spec'],

        // coverageReporter: {
        //     dir: 'test',
        //     reporters: [
        //         {
        //             type: 'html',
        //             subdir: 'report-html'
        //         },
        //         {
        //             type: 'cobertura',
        //             subdir: '.',
        //             file: 'testsResult.xml'
        //         }
        //     ]
        // },

        // web server port
        port: 9876,

        // enable / disable colors in the output (reporters and logs)
        colors: true,

        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        //logLevel: config.LOG_INFO,

        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,

        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['PhantomJS'],
        //browsers: ['Chrome'],

        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        //singleRun: false,
        //singleRun: true,

        // Concurrency level
        // how many browser should be started simultaneous
        concurrency: Infinity
    })
};