//http://stepansuvorov.com/blog/2016/02/angularjs-%D0%BE%D1%82-directive-%D0%BA-component/
//https://toddmotto.com/exploring-the-angular-1-5-component-method/
/**
 *  Creates FastSearchComponent.
 *  Main parameter is:
 *  - callback - it will be executed after user input.
 *  Also it contains secondary parameters:
 *  - min-letters-count - callback will be called only if input text length >= min-letters-count (0 by default)
 *  - delay - number of ms to wait after user finish input (500ms by default)
 *  - hint - text to be shown af hint ("" by default)
 *
 *  Use it like:
 *  <code><pre>
 *  &lt;div ng-controller="testFastSearchController">
 *      &lt;fast-search search-callback="doSearch(value);">&lt;/fast-search>
 *  &lt;/div>
 *  </pre></code>
 *  where doSearch is a function of testFastSearchController so controller
 *  may looks like:
 *  <code><pre>
 *  function testFastSearchController($scope) {
 *      $scope.doSearch = function (value) {
 *          alert("doSearch: value=" + value);
 *      };
 *  };
 *  </pre></code>
 *  Another example with secondary params:
 *  <code><pre>
 *  &lt;fast-search search-callback="doSearch(value);"
 *                      min-letters-count="3"
 *                      delay="500"
 *                      hint="Type to search"
 *  >&lt;/fast-search>
 *  </pre></code>
 */
function fastSearchComponent() {
    return {
        templateUrl: "ui-components/fastSearch/fastSearch.tmpl.html",
        controllerAs: "fastSearchCtrl",
        bindings: {
            searchCallback: "&",
            minLettersCount: '@',
            delay: '@',
            hint: '@'
        },
        //maybe $inject like https://github.com/johnpapa/angular-styleguide/blob/master/a1/i18n/ru-RU.md#style-y091
        //and https://github.com/johnpapa/angular-styleguide/blob/master/a1/i18n/ru-RU.md#ng-annotate
        controller: function ($timeout) {
            this.hint = this.hint || "";
            this.minLettersCount = this.minLettersCount || 0;
            this.delay = this.delay || 500;

            this.value = "";

            var timerId = null;
            var oldValue = null;

            var self = this;
            self.search = function () {
                if (debug) console.log(self.value);
                if (debug) console.log(self.minLettersCount);

                if (self.value.length >= self.minLettersCount && self.value != oldValue) {
                    $timeout.cancel(timerId);
                    timerId = $timeout(function () {
                        //https://weblogs.asp.net/dwahlin/creating-custom-angularjs-directives-part-3-isolate-scope-and-function-parameters
                        //http://stackoverflow.com/questions/17556703/angularjs-directive-call-function-specified-in-attribute-and-pass-an-argument-to
                        self.searchCallback({value: self.value});
                        $timeout.cancel(timerId);
                    }, self.delay);
                }

                oldValue = self.value;
            };
            self.cancelSearch = function () {
                $timeout.cancel(timerId);
            };
        },
    };
}