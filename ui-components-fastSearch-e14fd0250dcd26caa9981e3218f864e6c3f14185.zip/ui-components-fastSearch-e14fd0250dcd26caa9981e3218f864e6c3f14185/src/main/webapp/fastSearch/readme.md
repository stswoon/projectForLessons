# Fast Search Component
![Fast Search Component](https://git.netcracker.com/DEMO.Platform.Saas_Cloud_Catalog/ui-components/raw/fastSearch/docs/pictures/fastSearch.png "Fast Search Component")

Main parameter is:
* callback - it will be executed after user input.

Also it contains secondary parameters:
* min-letters-count - callback will be called only if input text length >= min-letters-count (0 by default)
* delay - number of ms to wait after user finish input (500ms by default)
* hint - text to be shown af hint ("" by default)

Use it like:
```html
<div ng-controller="testFastSearchController">
    <fast-search search-callback="doSearch(value);"></fast-search>
</div>
```
where `doSearch` is a function of `testFastSearchController` so controller may looks like:
```js
function testFastSearchController($scope) {
    $scope.doSearch = function (value) {
        alert("doSearch: value=" + value);
    };
};
```
And app.js may looks like:
```js
angular.module("app")
    .controller("testFastSearchController", testFastSearchController);
angular.module("app")
    .component("fastSearch", fastSearchComponent());
```

Another example with secondary params:
```html
<fast-search search-callback="doSearch(value);"
                    min-letters-count="3"
                    delay="500"
                    hint="Type to search"
></fast-search>
```



