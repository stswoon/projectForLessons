function testFastSearchController($scope) {
    $scope.doSearch = function (value) {
        alert("doSearch: value=" + value);
    };
};