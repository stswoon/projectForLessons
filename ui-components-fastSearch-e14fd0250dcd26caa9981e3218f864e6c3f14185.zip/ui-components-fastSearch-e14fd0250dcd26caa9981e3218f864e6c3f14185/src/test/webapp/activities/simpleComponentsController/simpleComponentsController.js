function simpleComponentsController() {
}