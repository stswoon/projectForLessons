angular.module("app", ['HtmlTemplates', 'ui.router'])
    .config(function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.when('', '/simpleComponents');
        $urlRouterProvider.otherwise("/none");
        $stateProvider
            .state('initDataState', {
                abstract: true,
                template: '<div ui-view autoscroll="true"></div>'
            })
            .state('404', {
                url: "/404",
                template: 'No such address',
                parent: 'initDataState'
            })
            .state('notReady', {
                url: "/notReady",
                template: 'Not ready yet',
                parent: 'initDataState'
            })
            .state('simpleComponents', {
                url: "/simpleComponents",
                controller: 'simpleComponentsController',
                controllerAs: "simpleComponentsCtrl",
                templateUrl: 'activities/simpleComponentsController/simpleComponentsController.tmpl.html',
                parent: 'initDataState'
            })
    }).run(function () {
    }
);

angular.module("app")
// Activities
    .controller("simpleComponentsController", simpleComponentsController)
//Test controllers
    .controller("testFastSearchController", testFastSearchController);

angular.module("app")
    .component("fastSearch", fastSearchComponent());

//todo log.setLevel("trace"); like https://www.npmjs.com/package/loglevel
debug = true;