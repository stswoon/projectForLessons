module.exports = {
    html2js: {
        rename: function (templateUrl, templateFile) {
            //test entities
            if (templateUrl.indexOf("activities/simpleComponentsController/simpleComponentsController.tmpl.html") > 0) {
                return "activities/simpleComponentsController/simpleComponentsController.tmpl.html";
            }

            //source entities
            if (templateUrl.indexOf("fastSearch/fastSearch.tmpl.html") > 0) {  //todo auto-alias
                return "ui-components/fastSearch/fastSearch.tmpl.html";
            }

            return templateUrl;
        }
    },
    sourceMapsOptions: {
        loadMaps: true,
        identityMap: true,
        largeFile: true
    },
    manifest: {
        dest: 'target/test/',
        src: "target/test/index.html",
        files: "target/test/rev-manifest.json"
    },
    cleanPaths: {
        nodes: ['./node_modules'],
        deps: ['./bower_components'],
        target: ['./target']
    },
    html: {
        src: [
            'src/test/webapp/**/*.tmpl.html',
            'target/dist/**/*.tmpl.html'
        ],
        srcProd: ['target/test/main.js', 'target/test/ngTemplates.js'],
        prodFileName: 'main.js',
        dest: 'target/test/',
        templateName: 'ngTemplates.js'
    },
    autoprefixer: {
        browsers: [
            'last 2 versions',
            'safari 5',
            'ie 9',
            'opera 12.1',
            'ios 6',
            'android 4'
        ],
        cascade: true
    },
    build: {
        srcJson: ['package.json', 'bower.json', 'readme.md'],
        srcAll: ['src/main/webapp/**', '!src/main/webapp/baseStyles/**', '!src/main/webapp/baseStyles'],
        destAll: 'target/dist/',
        srcBaseStyles: ["src/main/webapp/baseStyles/**", '!src/main/webapp/baseStyles/distinct/**', '!src/main/webapp/login/baseStyles/distinct'],
        destBaseStyles: 'target/dist/baseStyles/source',
        srcBaseStylesDistinct: ["src/main/webapp/baseStyles/distinct/**"],
        destBaseStylesDistinct: 'target/dist/baseStyles/distinct'
    },
    less: {
        src: 'src/test/webapp/main.less',
        srcProd: "target/test/main.css",
        dest: 'target/test/'
    },
    js: {
        srcProd: "target/test/main.js",
        outputFileName: "main.js",
        src: [
            "bower_components/underscore/underscore-min.js",
            "bower_components/jquery/dist/jquery.min.js",
            "bower_components/velocity/velocity.min.js",
            "bower_components/angular/angular.min.js",
            "bower_components/angular-cookies/angular-cookies.min.js",
            "bower_components/angular-animate/angular-animate.min.js",
            "bower_components/angular-sanitize/angular-sanitize.min.js",
            "bower_components/angular-ui-router/release/angular-ui-router.min.js",
            "bower_components/angular-file-saver/dist/angular-file-saver.bundle.min.js",
            "src/test/webapp/**/*.js",
            "target/dist/**/*.js",
            "target/test/ngTemplates.js"
        ],
        dest: 'target/test/'
    },
    watch: {
        src: ["src/**/*"]
    },
    copy: {
        srcIndex: ["src/test/webapp/index.html", "src/test/webapp/test.html"],
        srcBaseStylesDistinct: ["target/dist/baseStyles/distinct/**"],
        dest: "target/test/",
    },
    plugins: {
        scope: ['dependencies', 'devDependencies', 'peerDependencies'],
        rename: {
            'gulp-ng-annotate': 'ngannotate',
            'gulp-sourcemaps': 'sourcemaps',
            'gulp-plumber': 'plumber',
            'gulp-less': 'less',
            'gulp-autoprefixer': 'autoprefixer',
            'gulp-cssnano': 'minifyCSS',
            'gulp-image-data-uri': 'uri',
            'gulp-concat': 'concat',
            'gulp-uglify': 'uglify',
            'gulp-copy': 'copy',
            'gulp-rev': 'rev',
            'gulp-rev-replace': 'revreplace',
            'gulp-imagemin': 'imagemin',
            'gulp-ng-html2js': 'html2js',
            'gulp-minify-html': 'minifyHtml',
            'gulp-wrap': 'wrap',
        }
    }
};